﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for ClassReport
/// </summary>
public class ClassReport : GeneralASPClass
{
    private static DataTable dt1 = Dbase.SelectFromTable("SELECT CommentsDeviceTable.CommentID, CommentsDeviceTable.Content, UsersTable.UserID, UsersTable.UserName, CommentsDeviceTable.reportsCount FROM UsersTable INNER JOIN CommentsDeviceTable ON UsersTable.UserID = CommentsDeviceTable.CommenterUserID WHERE reportsCount > 0", "DB.accdb");
    public ClassReport() : base("ReportTable", "DB.accdb")
    {
        dt1 = Dbase.SelectFromTable("SELECT CommentsDeviceTable.CommentID, CommentsDeviceTable.Content, UsersTable.UserID, UsersTable.UserName, CommentsDeviceTable.reportsCount FROM UsersTable INNER JOIN CommentsDeviceTable ON UsersTable.UserID = CommentsDeviceTable.CommenterUserID WHERE reportsCount > 0", "DB.accdb");
        //
        // TODO: Add constructor logic here
        //
    }
    public static string  getAttributeNameInClass(int i)
    {
        if (i < dt1.Columns.Count)

            return dt1.Columns[i].ColumnName;
        else
            return "";
    }
    public static DataTable getAllReportsForID(string ID)
    {
        string sql = "SELECT * FROM ReportTable WHERE CommentID =" + ID;
        return Dbase.SelectFromTable(sql, "DB.accdb");
    }
    public static DataTable getAllReportedComments(string SearchBy = "", string value ="")
    {
        DataTable dt=null;
        string sql = "SELECT CommentsDeviceTable.CommentID, CommentsDeviceTable.Content, UsersTable.UserID, UsersTable.UserName, CommentsDeviceTable.reportsCount FROM UsersTable INNER JOIN CommentsDeviceTable ON UsersTable.UserID = CommentsDeviceTable.CommenterUserID WHERE reportsCount > 0";
        dt= Dbase.SelectFromTable(sql, "DB.accdb");
        if (SearchBy == "")
        {
            return dt;
        }
        else
        {
             sql = "SELECT CommentsDeviceTable.CommentID, CommentsDeviceTable.Content, UsersTable.UserID, UsersTable.UserName, CommentsDeviceTable.reportsCount FROM UsersTable INNER JOIN CommentsDeviceTable ON UsersTable.UserID = CommentsDeviceTable.CommenterUserID WHERE reportsCount > 0 AND "+SearchBy+" = ";
            if (dt.Columns[SearchBy].DataType.ToString().Equals("System.DateTime"))
            {
                sql += " #" + DateTime.Parse(value).ToShortDateString() + "#";
            }
            else if (dt.Columns[SearchBy].DataType.ToString().Equals("System.String"))
            {
                sql +="\'" + value + "\'";
            }
            else
                sql +=  value;
            return Dbase.SelectFromTable(sql, "DB.accdb");
        }
    }
    
}
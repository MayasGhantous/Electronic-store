﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using com.currencysystem.fx;
using localhost;

public partial class AllFlights : System.Web.UI.Page
{

    public DataTable DataSource
    {
        get
        {
            if (ViewState["DataSource"] == null)
            {
                //string name = RegionInfo.CurrentRegion.DisplayName;
                ViewState["DataSource"] = this.DataList1.DataSource as DataTable;
            }
            return ViewState["DataSource"] as DataTable;
        }
        set
        {
            ViewState["DataSource"] = value;
        }

    }
    private string weight
    {
        get
        {

            string s = ViewState["weight"] as string;
            return s;
        }
        set
        {
            ViewState["weight"] = value;
        }

    }
    private string price
    {
        get
        {

            string s = ViewState["price"] as string;
            return s;
        }
        set
        {
            ViewState["price"] = value;
        }

    }
    private string amount
    {
        get
        {

            string s = ViewState["amount"] as string;
            return s;
        }
        set
        {
            ViewState["amount"] = value;
        }

    }
    private string id
    {
        get
        {

            string s = ViewState["id"] as string;
            return s;
        }
        set
        {
            ViewState["id"] = value;
        }

    }


    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LabelMessage.Text = "";
            LabelInfo.Text = "";
            if (!IsPostBack)
            {
                ClassDevicesCarts cdc = (ClassDevicesCarts)Session["cartToFlight"];

                if (Session["LoggedInUser"] != null)
                {

                    AirplaneWS aw = new AirplaneWS();
                    string country = ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country");
                    DataSource = aw.getAllFromTo("US", country);
                    ViewState["PricePerKG"] = new ArrayList();
                    ViewState["ArrivingTime"] = new ArrayList();
                    if (DataSource == null)
                    {
                        LabelInfo.Text = "Currently there is no Flights";
                        return;

                    }
                    string[] s1 = { "DeviceID" };
                    string[] s2 = { ((ClassDevicesCarts)Session["cartToFlight"]).DeviceID };
                    ClassDevices cd = new ClassDevices();
                    cd = (ClassDevices)cd.completeObj(s1, s2);
                    id = ((ClassDevicesCarts)Session["cartToFlight"]).DeviceID;
                    weight = cd.getAttributeByString("Weight");
                    price = cd.getAttributeByString("Price");
                    amount = cdc.amount;

                    DataList1.DataSource = DataSource;
                    DataList1.DataBind();
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
                if (Session["cartToFlight"] == null)
                {
                    Response.Redirect("Cart.aspx");
                }
                else
                {
                    ClassDevices cd = new ClassDevices();
                    string[] s1 = { "DeviceID" };
                    string[] s2 = { cdc.DeviceID };
                    cd.completeObj(s1, s2);
                    weight = cd.getAttributeByString("Weight");
                    ViewState["id"] = cdc.PurchaseID;
                }

            }
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in AllFlights::PageLoad=> " + ex.Message;
        }

    }
    public string getFee(string ID)
    {
        try
        {
            double p1 = double.Parse(((ArrayList)ViewState["PricePerKG"])[int.Parse(ID)].ToString());
            // string s = (string)ViewState["weight"];
            string s = weight;
            double price1 = int.Parse(amount) * (int.Parse(price) + double.Parse(s) * p1);
            CurrencyServer currency = new CurrencyServer();
            return currency.ConvertToNum("", "USD", currency.CountryToCurrency("", ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country"), true), price1, true, "", "") + " " + currency.CurrencySymbol("", currency.CountryToCurrency("", ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country"), true), "");
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in AllFlights::getFee=> " + ex.Message;
            return "";
        }
    }
    public string getArrivingTime(string ID)
    {
        try
        {
            if (int.Parse(ID) < ((ArrayList)ViewState["ArrivingTime"]).Count)
                return ((ArrayList)ViewState["ArrivingTime"])[int.Parse(ID)].ToString();
            return "";
        }
        catch (Exception ex)
        {

            LabelMessage.Text = "ERROR in AllFlights::getArrivingTime=> " + ex.Message;
            return "";
        }
    }
    public DataTable getFlight(string ID)
    {
        try
        {
            AirplaneWS ws = new AirplaneWS();
            DateTime date;
            double Weight;
            //GridView current = (GridView)gv;
            //current.DataSource = ws.getFlightDescriptiion(DataSource.Rows[int.Parse(ID)]["Flight"].ToString(),out date,out Weight);
            string flight = DataSource.Rows[int.Parse(ID)]["Flight"].ToString();
            //current.DataBind();
            DataTable ste = ws.getFlightDescriptiion(flight, out date, out Weight);
            ((ArrayList)ViewState["PricePerKG"]).Add(Weight);
            ((ArrayList)ViewState["ArrivingTime"]).Add(date);
            return ste;
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in AllFlights::getFlight=> " + ex.Message;
            return null;
        }
    }

    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Book")
            {
                double p1 = double.Parse(((ArrayList)ViewState["PricePerKG"])[int.Parse(e.CommandArgument.ToString())].ToString());
                // string s = (string)ViewState["weight"];
                string s = weight;
                double price1 = int.Parse(amount) * (int.Parse(price) + double.Parse(s) * p1);
                VisaNumber visa = new VisaNumber();
                if (!visa.exists(((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Visa")))
                {
                    LabelInfo.Text = "please change the visa its fake";
                    return;
                }
                else
                {

                    visa.decreaseAmount(((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Visa"), price1);
                    visa.increseAmount("4627881625213655", price1);
                }
                ClassDevicesCarts.updateTime(((ClassDevicesCarts)Session["cartToFlight"]).PurchaseID, (((ArrayList)ViewState["ArrivingTime"])[int.Parse(e.CommandArgument.ToString())]).ToString());
                Response.Redirect("ShowArrivalTime.aspx");

            }

        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in AllFlights::DataList1_ItemCommand=> " + ex.Message;

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["Message"] != null)
            {
                LabelMessage.Text = Session["Message"] as string;
                Session["Message"] = "";
            }
            if (Session["LoggedinUser"] == null || !bool.Parse(((ClassUsers)Session["LoggedinUser"]).getAttributeByString("IsAdmin")))
            {
                if (Session["InContactUs"] == null || !(bool)Session["InContactUs"])
                {
                    LabelContactUs.Text = "<a href = \"ContactUs.aspx\" > Contact us </ a >";
                }
                else
                {
                    LabelContactUs.Text = "";
                    Session["InContactUs"] = false;
                }

            }
            if (Session["LoggedinUser"] == null)
            {

                RemoveMenuItem("Profile");
                RemoveMenuItem("Admin");

            }
            else
            {
                RemoveMenuItem("Log_in");
                RemoveMenuItem("Sing_Up");
                if (!bool.Parse(((ClassUsers)Session["LoggedinUser"]).getAttributeByString("IsAdmin")))
                {
                    RemoveMenuItem("Admin");
                }
            }
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERORR in MasterPage::Page_Load=>"+ex.Message;
        }

    }
    private void RemoveMenuItem(string Value)
    {
        MenuItem mi = Menu1.FindItem(Value);
        if (mi != null)
        {
            Menu1.Items.Remove(mi);
        }

    }


}

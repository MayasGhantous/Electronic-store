﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SeeWhy : System.Web.UI.Page
{
    private string CommenterID
    {
        get
        {
            return (string)ViewState["CommenterID"];
        }
        set
        {
            ViewState["CommenterID"] = value;
        }
    }
    private string CommentContent
    {
        get
        {
            return (string)ViewState["CommentContent"];
        }
        set
        {
            ViewState["CommentContent"] = value;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                if (Session["LoggedInUser"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
                else if (Request.QueryString["CommentID"] == null)
                {
                    Response.Redirect("GridViewReports.aspx");
                }
                string Id = Request.QueryString["CommentID"];
                string[] s1 = { "CommentID" };
                string[] s2 = { Id };
                ClassCommentsDevice ccd = new ClassCommentsDevice();
                ccd = (ClassCommentsDevice)ccd.completeObj(s1, s2);
                CommentContent = ccd.getAttributeByString("Content");
                CommenterID = ccd.getAttributeByString("CommenterUserID");
                DataListWhy.DataSource = ClassReport.getAllReportsForID(Id);
                DataListWhy.DataBind();
                Label T1 = (Label)DataListWhy.Controls[0].FindControl("LabelCommenterUserName");
                T1.Text = CommenterID;
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in SeeWhy::Page_Load=> " + ex.Message;

        }
    }
    public string getCommentContent()
    {
        try
        {

            return CommentContent;
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in SeeWhy::getCommentContent=> " + ex.Message;
        }
        return "";
    }

    protected void DataListWhy_ItemCommand(object source, DataListCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "BannedReporter")
            {
                ClassUsers cu = new ClassUsers();
                string[] args = e.CommandArgument.ToString().Split(' ');
                string[] s1 = { "UserID" };
                string[] s2 = { args[0] };
                cu = (ClassUsers)cu.completeObj(s1, s2);
                if (bool.Parse(cu.getAttributeByString("Isadmin")))
                {
                    LabelError.Text = "You cant banned an admin but the report will be deleted";
                    s1[0] = "ReportID";
                    s2[0] = args[1];
                    ClassReport cr = new ClassReport();
                    cr.delete(s1, s2);
                    DataListWhy.DataSource = ClassReport.getAllReportsForID(Request.QueryString["CommentID"]);
                    DataListWhy.DataBind();
                }
                else
                {
                    TextBox T1 = (TextBox)DataListWhy.Controls[0].FindControl("TextBoxTime");
                    int Time = int.Parse(T1.Text);
                    string[] s3 = { "Start_day", "Last_day", "Isbanned" };
                    string[] s4 = { DateTime.Now.ToShortDateString(), DateTime.Now.AddDays(Time).ToShortDateString(), true.ToString() };
                    cu.update(s3, s4, s1, s2);
                    s1[0] = "ReportID";
                    s2[0] = args[1];
                    ClassReport cr = new ClassReport();
                    cr.delete(s1, s2);
                    DataListWhy.DataSource = ClassReport.getAllReportsForID(Request.QueryString["CommentID"]);
                    DataListWhy.DataBind();
                }
                s1[0] = "CommentID";
                s2[0] = Request.QueryString["CommentID"];
                ClassCommentsDevice ccd = new ClassCommentsDevice(); 
                 ccd = (ClassCommentsDevice)ccd.completeObj(s1,s2);
                string[] s5 = { "reportsCount"};
                string[] s6 = {( int.Parse(ccd.getAttributeByString("reportsCount"))-1).ToString()};
                ccd.update(s5,s6,s1,s2);
                if(int.Parse(ccd.getAttributeByString("reportsCount"))==1)
                {
                    Response.Redirect("GridViewReports.aspx");
                }
                else
                {
                    DataListWhy.DataSource = ClassReport.getAllReportsForID(Request.QueryString["CommentID"]);
                    DataListWhy.DataBind();
                    Label T1 = (Label)DataListWhy.Controls[0].FindControl("LabelCommenterUserName");
                    T1.Text = CommenterID;
                }
             //   Response.Redirect("GridViewReports.aspx");
            }
            else if(e.CommandName == "BannedCommenter")
            {
                ClassUsers cu = new ClassUsers();
                string[] s1 = { "UserID"};
                string[] s2 = {CommenterID };
                cu = (ClassUsers)cu.completeObj(s1,s2);
                if (bool.Parse(cu.getAttributeByString("Isadmin")))
                {
                   // LabelError.Text = "You cant banned an admin but the comment will be deleted";
                    s1[0] = "CommentID";
                    s2[0] = Request.QueryString["CommentID"];
                    ClassCommentsDevice cr = new ClassCommentsDevice();
                    cr.delete(s1, s2);
                }
                else
                {
                    TextBox T1 = (TextBox)DataListWhy.Controls[0].FindControl("TextBoxTime");
                    int Time = int.Parse(T1.Text);
                    string[] s3 = { "Start_day", "Last_day", "Isbanned" };
                    string[] s4 = { DateTime.Now.ToShortDateString(), DateTime.Now.AddDays(Time).ToShortDateString(), true.ToString() };
                    cu.update(s3, s4, s1, s2);
                    s1[0] = "CommentID";
                    s2[0] = Request.QueryString["CommentID"];
                    ClassCommentsDevice cr = new ClassCommentsDevice();
                    cr.delete(s1, s2);

                }
                Response.Redirect("GridViewReports.aspx");
            }
            else if(e.CommandName=="delete")
            {
              string [] s1 = { "CommentID" };
                string []s2 = { Request.QueryString["CommentID"] };
                ClassCommentsDevice cr = new ClassCommentsDevice();
                cr.delete(s1, s2);
                Response.Redirect("GridViewReports.aspx");
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in SeeWhy::DataListWhy_ItemCommand=> " + ex.Message;
        }
    }

    
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if(Session["LoggedInUser"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            if (Request.QueryString["FeadbackID"] != null)
            {
                Session["Show_Last"] = "Feadback";
                ClassFeadbacks obj = new ClassFeadbacks();
                string[] s1 = { "FeadbackID" };
                string[] s2 = { Request.QueryString["FeadbackID"] };
                ClassFeadbacks F = (ClassFeadbacks)obj.completeObj(s1, s2);
                TextBoxFullName.Text = F.getAttributeByString("FullName");
                TextBoxSubject.Text = F.getAttributeByString("Subject");
                TextBoxEmail.Text = F.getAttributeByString("Email");
                TextBoxContent.Text = F.getAttributeByString("Content");
            }
            
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in Answer::Page_Load=>" + ex.Message;
        }
    }

    protected void ButtonAnswer_Click(object sender, EventArgs e)
    {
        try
        {
            MailMessage message = new MailMessage();
            SmtpClient smtp = new SmtpClient();
            message.From = new MailAddress("new.eshop123@gmail.com");
            message.To.Add(new MailAddress(TextBoxEmail.Text));
            message.Subject = TextBoxSubject.Text;
            message.Body = TextBoxAnswer.Text;
            smtp.Port = 587;
            smtp.Host = "smtp.gmail.com"; //for gmail host  
            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential("new.eshop123@gmail.com", "Mma213461692");
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Send(message);
            if (CheckBoxWith.Checked)
            {
                string[] s1 = { "FeadbackID"};
                string[] s2 = { Request.QueryString["FeadbackID"] };
                ClassFeadbacks cf = new ClassFeadbacks();
                cf.delete(s1,s2);
            }
            Response.Redirect("GridviewAnswer.aspx");
        }
        catch (Exception) { LabelMessage.Text = "ERORR in Answer::ButtonAnswer_Click"; return; }

    }

    protected void ButtonCancel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("GridviewAnswer.aspx");
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERORR in Answer::ButtonCancel_Click" + ex.Message;
        }
    }
}
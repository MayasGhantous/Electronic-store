﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Windows.Forms.Design.Behavior;
//using System.Globalization;

public partial class GridViewOurDevices : System.Web.UI.Page
{
    //public static string today()
    //{
    //    return DateTime.Now.ToShortDateString();
    //}
    //public static string getMinus18()
    //{
    //    return DateTime.Now.AddYears(-18).ToShortDateString();
    //}
    //public static string getMinus100()
    //{
    //    return DateTime.Now.AddYears(-100).ToShortDateString();
    //}
    public DataTable GVDataSource
    {
        get
        {
            if (ViewState["GVDataSource"] == null)
            {
                //string name = RegionInfo.CurrentRegion.DisplayName;
                ViewState["GVDataSource"] = this.GridViewsUsers.DataSource as DataTable;
            }
            return ViewState["GVDataSource"] as DataTable;
        }
        set
        {
            ViewState["GVDataSource"] = value;
        }
    }
    public string SortExpression
    {
        get
        {
            if (ViewState["SortExpression"] == null)
            {
                ViewState["SortExpression"] = "Do Not Sort";
            }
            return ViewState["SortExpression"].ToString();
        }
        set
        {
            ViewState["SortExpression"] = value;
        }
    }
    public SortDirection GridViewSortDirection
    {
        get
        {
            if (ViewState["GridViewSortDirection"] == null)
            {
                ViewState["GridViewSortDirection"] = SortDirection.Ascending;
            }
            return (SortDirection)ViewState["GridViewSortDirection"];
        }
        set
        {
            ViewState["GridViewSortDirection"] = value;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LabelError.Text = "";
            LabelMessage.Text = "";
            if (!IsPostBack)
            {
                if (Session["LoggedInUser"] == null || bool.Parse(((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Isadmin")) == false)
                {
                    Session["Message"] = "Please login as an admin";
                    Response.Redirect("Login.aspx");
                }
                ClassDevices cu = new ClassDevices();
                int i = 0;
                string s = cu.getAttributeName(i);
                while (s != "")
                {
                    if (s != "OrginalImg")
                    {
                        DropDownList1.Items.Add(s);
                    }
                    i++;
                    s = cu.getAttributeName(i);
                }
                FillGrid();
                DropDownList DDLType = (DropDownList)GridViewsUsers.FooterRow.FindControl("DropDownListNewType");
                DDLType.DataBind();


            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewOurDevices::FillGrid=> " + ex.Message;

        }
    }
    private void FillGrid(string Name = "", string value = "")
    {
        try
        {
            ClassDevices cu = new ClassDevices();
            DataTable dt = null;
            if (Name == "" || value == "" || value == null || Name == null)
            {
                dt = cu.GetDtAttribute();
                GridViewsUsers.DataSource = dt;
                GVDataSource = dt;
                GridViewsUsers.DataBind();
            }
            else
            {
                string[] s1 = { Name };
                string[] s2 = { value };
                dt = cu.getDataTableWhere(s1, s2);
                GridViewsUsers.DataSource = dt;
                GVDataSource = dt;
                GridViewsUsers.DataBind();
            }
            if (dt.Rows.Count == 0)
            {
                LabelMessage.Text = "You dont have any data";
                GeneralASPClass.ShowEmptyGridView(GridViewsUsers, dt);
            }
            else
            {
                LabelMessage.Text = "";

            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::FillGrid=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            GridViewsUsers.EditIndex = -1;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_RowCancelingEdit =>" + ex.Message;
        }
    }
    protected void GridViewsUsers_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            GridViewsUsers.EditIndex = e.NewEditIndex;
            string old_un = ((Label)GridViewsUsers.Rows[e.NewEditIndex].FindControl("LabelName")).Text;
            Session["Name"] = old_un;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_RowEditing:: " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {

            LabelError.Text = "";
            ClassDevices User = new ClassDevices();
            string DeviceID = e.Keys[0].ToString();
            string Name = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxName")).Text;
            string Type = ((DropDownList)GridViewsUsers.Rows[e.RowIndex].FindControl("DropDownListType")).Text;
            string Rate = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxRate")).Text;
            string price = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxPrice")).Text;

            string weight = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxWeight")).Text;
            string Description = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxDescription")).Text;
            FileUpload FUOrginalImg = ((FileUpload)GridViewsUsers.Rows[e.RowIndex].FindControl("FileUploadOrginalImg"));
            if (FUOrginalImg.HasFile)
            {
                if (!FUOrginalImg.PostedFile.ContentType.Contains("image"))
                {
                    LabelError.Text = "this is not an img";
                    return;

                }
                else if (FUOrginalImg.PostedFile.ContentLength > 100000000)
                {
                    LabelError.Text = "The size of the Img must be <= 100MB";
                    return;
                }
                string[] s1 = { "Name", "Weight", "Type", "Rate", "Price", "Description", "OrginalImg" };

                Guid g = Guid.NewGuid();
                string path = Request.PhysicalApplicationPath;
                //System.IO.File.Delete(path+);
                FUOrginalImg.SaveAs(path + "Img\\" + g.ToString() + "." + (FUOrginalImg.FileName.Split('.'))[1]);
                string[] s2 = { Name, weight, Type, Rate, price, Description, "Img\\" + g.ToString() + "." + (FUOrginalImg.FileName.Split('.'))[1] };
                string[] s3 = { "DeviceID" };
                string[] s4 = { DeviceID };
                ClassDevices C = new ClassDevices();
                C = (ClassDevices)C.completeObj(s3, s4);
                System.IO.File.Delete(path + C.getAttributeByString("OrginalImg"));
                if (Session["Name"].ToString() == Name)
                {
                    C.update(s1, s2, s3, s4);
                    GridViewsUsers.EditIndex = -1;
                }
                else if (C == null)
                {
                    C = new ClassDevices();
                    C.update(s1, s2, s3, s4);
                    GridViewsUsers.EditIndex = -1;
                }
                else
                {
                    LabelError.Text = "Name is Already used";
                    return;
                }
            }
            else
            {
                string[] s1 = { "Name", "Weight", "Type", "Rate", "Price", "Description" };
                string[] s2 = { Name, weight, Type, Rate, price, Description };
                string[] s3 = { "DeviceID" };
                string[] s4 = { DeviceID };
                ClassDevices C = new ClassDevices();
                C = (ClassDevices)C.completeObj(s3, s4);
                if (Session["Name"].ToString() == Name)
                {
                    C.update(s1, s2, s3, s4);
                    GridViewsUsers.EditIndex = -1;
                }
                else if (C == null)
                {
                    C = new ClassDevices();
                    C.update(s1, s2, s3, s4);
                    GridViewsUsers.EditIndex = -1;
                }
                else
                {
                    LabelError.Text = "Name is Already used";
                    return;
                }
            }
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);

        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_RowUpdating=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            string DI = ((Label)GridViewsUsers.Rows[e.RowIndex].FindControl("LabelDeviceID")).Text;
            string[] s1 = { "DeviceID" };
            string[] s2 = { DI };
            ClassDevices cd = new ClassDevices();
            cd = (ClassDevices)cd.completeObj(s1, s2);
            string path = Request.PhysicalApplicationPath;
            System.IO.File.Delete(path + cd.getAttributeByString("OrginalImg"));
            ClassImagesNameGUID x = new ClassImagesNameGUID();
            DataTable dt1 = x.getDataTableWhere(s1, s2);
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                System.IO.File.Delete(path + dt1.Rows[i]["GUID"]);
            }
            cd.delete(s1, s2);
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_RowDeleting=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Insert")
            {
                ClassDevices Device = new ClassDevices();
                string Name = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewName")).Text;
                string Type = ((DropDownList)GridViewsUsers.FooterRow.FindControl("DropDownListNewType")).Text;
                string Rate = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewRate")).Text;
                string Price = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewPrice")).Text;
                string weight = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewWeight")).Text;
                string Description = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewDescription")).Text;
                FileUpload FileUpload1 = ((FileUpload)GridViewsUsers.FooterRow.FindControl("FileUploadNewOrginalImg"));
                if (!FileUpload1.PostedFile.ContentType.Contains("image"))
                {
                    LabelError.Text = "this is not an img";
                    return;

                }
                else if (FileUpload1.PostedFile.ContentLength > 100000000)
                {
                    LabelError.Text = "The size of the Img must be <= 100MB";
                    return;
                }
                string strRealPath = Request.PhysicalApplicationPath;
                strRealPath += "img\\";

                Guid g = Guid.NewGuid();
                string ImgName = g.ToString();
                //    Request.LogonUserIdenti

                string[] s1 = { "Name", "Weight", "Type", "Rate", "Price", "Description", "OrginalImg" };
                string[] s2 = { Name, weight, Type, Rate, Price, Description, "img\\" + ImgName + "." + (FileUpload1.FileName.Split('.'))[1] };
                string[] s3 = { "Name" };
                string[] s4 = { Name };
                Device = (ClassDevices)Device.completeObj(s3, s4);
                if (Device == null)
                {
                    Device = new ClassDevices();
                    Device.insert(s1, s2);
                    FileUpload1.SaveAs(strRealPath + ImgName + "." + (FileUpload1.FileName.Split('.'))[1]);
                    FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
                    LabelError.Text = "";
                }
                else
                {
                    LabelError.Text = "This name Is Already Used";
                    return;
                }


            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_RowCommand=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_Sorting(object sender, GridViewSortEventArgs e)
    {
        try
        {
            string strSortExpression = e.SortExpression;
            SortExpression = e.SortExpression;
            if (GridViewSortDirection == SortDirection.Ascending)
            {
                GridViewSortDirection = SortDirection.Descending;
                SortGridView(strSortExpression, "DESC");
            }
            else
            {
                GridViewSortDirection = SortDirection.Ascending;
                SortGridView(strSortExpression, "ASC");
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_Sorting=> " + ex.Message;

        }
    }
    private void SortGridView(string sortexpression, string direction)
    {
        try
        {
            if (GVDataSource == null)
                return;
            if (sortexpression == "Do Not Sort")
                return;
            DataView dv = new DataView(GVDataSource);
            dv.Sort = sortexpression + " " + direction;
            this.GridViewsUsers.DataSource = dv;
            GridViewsUsers.DataBind();
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewOurDevices::SortGridView=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            GridViewsUsers.PageIndex = e.NewPageIndex;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
            if (GridViewSortDirection == SortDirection.Ascending)
            {
                SortGridView(SortExpression, "asc");
            }
            else
            {
                SortGridView(SortExpression, "desc");
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewOurDevices::GridViewsUsers_PageIndexChanging=> " + ex.Message;

        }
    }


    protected void ButtonSearch_Click(object sender, EventArgs e)
    {
        try
        {
            ClassDevices cd = new ClassDevices();
            ViewState["ToSearch"] = DropDownList1.SelectedValue;
            ViewState["Vlaue"] = TextBoxValue.Text;
            if (cd.getTypeOf((string)ViewState["ToSearch"]).ToString().Equals("System.DateTime"))
            {
                DateTime dateTime;
               if( !DateTime.TryParse((string)ViewState["Vlaue"],out dateTime))
                {
                    LabelMessage.Text = "This is not a real date";
                    return;
                }
            }
            else if(cd.getTypeOf((string)ViewState["ToSearch"]).ToString().Equals("System.Boolean"))
            {
                 bool dateTime;
                if (!bool.TryParse((string)ViewState["Vlaue"], out dateTime))
                {
                    LabelMessage.Text = "This is not a real boolean";
                    return;

                }
            }
            else if(cd.getTypeOf((string)ViewState["ToSearch"]).ToString().Equals("System.Int32"))
            {
                int dateTime;
                if (!int.TryParse((string)ViewState["Vlaue"], out dateTime))
                {
                    LabelMessage.Text = "This is not a real intger";
                    return;

                }
            }
            else
            {
                
                double dateTime;
                if (!double.TryParse((string)ViewState["Vlaue"], out dateTime))
                {
                    LabelMessage.Text = "This is not a real double";
                    return;

                }
            }
            GridViewsUsers.PageIndex = 0;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
            if (GridViewSortDirection == SortDirection.Ascending)
            {
                SortGridView(SortExpression, "asc");
            }
            else
            {
                SortGridView(SortExpression, "desc");
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewOurDevices::ButtonSearch_Click=> " + ex.Message;

        }
    }

    protected void DropDownListNewType_Load(object sender, EventArgs e)
    {
        try
        {
            DropDownList d = (DropDownList)sender;

            d.DataSource = ClassKind.GetAllTheKindsAndFirst("");
            d.DataBind();
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewOurDevices::DropDownListNewType_Load=> " + ex.Message;

        }
    }


    protected void DropDownListType_Load(object sender, EventArgs e)
    {
        try
        {
            DropDownList d = (DropDownList)sender;
            //  d.DataBind();
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewOurDevices::DropDownListType_Load=> " + ex.Message;

        }
    }


    protected void Buttonkinds_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("GridViewKinds.aspx");
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewOurDevices::Buttonkinds_Click=> " + ex.Message;

        }
    }
}
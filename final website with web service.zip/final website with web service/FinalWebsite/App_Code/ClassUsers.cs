﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ClassUsers
/// </summary>
public class ClassUsers:GeneralASPClass
{//we need banned
   
   // private static DataTable dt = Dbase.SelectFromTable("SELECT * FROM UsersTable","DB.accdb");
    public ClassUsers():base("UsersTable", "DB.accdb")
    {
    }
    //protected override void NameDataTable()
    //{
    //    dtAttribute.TableName = "UsersTable";
    //}
    
    
    public static void Banned()
    {
        string SQL = "SELECT * FROM UsersTable";
        DataTable dt = Dbase.SelectFromTable(SQL, "DB.accdb");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            bool IsBanned = false;
            DateTime FDay = DateTime.Parse(dt.Rows[i]["Start_day"].ToString());
            DateTime LDay = DateTime.Parse(dt.Rows[i]["Last_day"].ToString());
            DateTime NDay = DateTime.Now;
             if(FDay.CompareTo(NDay)<=0&& LDay.CompareTo(NDay) >0)
            {
                IsBanned = true;
            }
            SQL = "UPDATE UsersTable SET Isbanned = "+IsBanned+" WHERE UserID ="+ dt.Rows[i]["UserID"];
            Dbase.ChangeTable(SQL,"DB.accdb");
        }
    }
    
    public static int DateMines(DateTime D1, DateTime D2)
    {
        int Days1 = D1.Year * 365 + D1.Month * 30 + D1.Day;
        int Days2 = D2.Year * 365 + D2.Month * 30 + D2.Day;
        return Days1 - Days2;
    }
   
}
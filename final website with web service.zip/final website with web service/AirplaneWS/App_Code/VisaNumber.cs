﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for VisaNumber
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class VisaNumber : System.Web.Services.WebService
{

    public VisaNumber()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }
    [WebMethod]
    public void decreaseAmount(string visa, double amount)
    {
        string sql = "UPDATE VisaTable SET amount = amount-" + amount + " WHERE VisaNumber=\'" + visa + "\'";
        Dbase.ChangeTable(sql, "WSDB.accdb");
    }
    [WebMethod]
    public bool exists(string visa)
    {
        string sql = "SELECT * FROM VisaTable WHERE VisaNumber=\'" + visa + "\'";
        return (Dbase.SelectFromTable(sql, "WSDB.accdb").Rows.Count > 0);
    }
    [WebMethod]
    public void increseAmount(string visa, double amount)
    {
        string sql = "UPDATE VisaTable SET amount = amount+" + amount + " WHERE VisaNumber=\'" + visa + "\'";
        Dbase.ChangeTable(sql, "WSDB.accdb");
    }
   
    public string GenrateNewVisa()
    {
        Random R = new Random();
        while (true)
        {
            string visa = "";
            for (int i = 1; i <= 16; i++)
            {
                visa += R.Next(0, 10);
            }
            string sql = "SELECT * FROM VisaTable WHERE VisaNumber=\'" + visa + "\'";
            if (Dbase.SelectFromTable(sql, "WSDB.accdb").Rows.Count == 0)
            {
                sql = "INSERT INTO VisaTable ([VisaNumber]) VALUES (" + visa + ")";
                Dbase.ChangeTable(sql, "WSDB.accdb");
                return visa;
                //   break;
            }
        }

    }
}

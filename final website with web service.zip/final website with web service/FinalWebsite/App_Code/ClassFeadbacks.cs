﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ClassFeadbacks
/// </summary>
public class ClassFeadbacks:GeneralASPClass
{
    
    //private static DataTable dt = Dbase.SelectFromTable("SELECT * FROM FeadbacksTable","DB.accdb");
    public ClassFeadbacks():base("FeadbacksTable", "DB.accdb")
    {
       
    }
    //protected override void NameDataTable()
    //{
    //    dtAttribute.TableName = "FeadbacksTable";
    //}
   
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ContactUs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        Session["InContactUs"] = true;
        if(Session["LoggedInUser"]!=null)
        {
            TextBoxFullName.Enabled = false;
            TextBoxFullName.Text = (Session["LoggedInUser"] as ClassUsers).getAttributeByString("FullName");
            TextBoxEmail.Enabled = false;
            TextBoxEmail.Text = (Session["LoggedInUser"] as ClassUsers).getAttributeByString("Email");
        }
    }

    protected void ButtonSubmet_Click(object sender, EventArgs e)
    {
        if (Session["LoggedInUser"] == null)
        {
            string[] s1 = {"FullName","Email","Subject","Content","DateOfRelease" };
            string[] s2 = { TextBoxFullName.Text, TextBoxEmail.Text, TextBoxSubject.Text, TextBoxContent.Text, DateTime.Now.ToString() };
            ClassFeadbacks F = new ClassFeadbacks();
            F.insert(s1, s2);
            LabelMessage.Text = "The feadback submeted successfully";
        }
        else
        {
            TextBoxFullName.Enabled = false;
            TextBoxEmail.Enabled= false;
            string[] s1 = { "FullName", "Email", "Subject", "Content", "DateOfRelease" };
            string[] s2 = { ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("FullName"), ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Email"), TextBoxSubject.Text, TextBoxContent.Text, DateTime.Now.ToString() };
            ClassFeadbacks F = new ClassFeadbacks();
            F.insert(s1, s2);
            LabelMessage.Text = "The feadback submeted successfully";
        }
    }

    protected void ButtonCancel_Click(object sender, EventArgs e)
    {
        LabelMessage.Text = "You have canceled the feadback";
    }
}
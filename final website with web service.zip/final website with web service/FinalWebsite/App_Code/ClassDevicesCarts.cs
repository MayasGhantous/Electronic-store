﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;


/// <summary>
/// Summary description for ClassDevicesCarts
/// </summary>
public class ClassDevicesCarts
{
    public string PurchaseID, DeviceID, UserID,amount,arrivalTime;
    public ClassDevicesCarts()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public static void DeleteById (string ID)
    {
        string SQL = "DELETE * FROM DevicesCartTable WHERE PurchaseID=" + ID;
        Dbase.ChangeTable(SQL, "DB.accdb");
        

    }
    public static DataTable GetDevices(string ID)
    {
        string sql = "SELECT UsersTable.UserID, DevicesTable.DeviceID, DevicesTable.Name, DevicesTable.Type, DevicesTable.Rate, DevicesTable.OrginalImg, DevicesTable.Price, DevicesTable.Description FROM UsersTable INNER JOIN(DevicesTable INNER JOIN DevicesCartTable ON DevicesTable.DeviceID = DevicesCartTable.DeviceID) ON UsersTable.UserID = DevicesCartTable.UserID WHERE DevicesCartTable.UserID=" + ID + " AND ArrivalTime = #1/1/2001#";
        DataTable dt = Dbase.SelectFromTable(sql, "DB.accdb");
        if (dt.Rows.Count < 1)
        {
            return null;
        }
        else
        {
            return dt;
        }
    }
    public static DataTable getpurchases(string UserID)
    {
        string sql = "SELECT DevicesCartTable.PurchaseID, DevicesTable.Name, DevicesCartTable.UserID, DevicesCartTable.ArrivalTime, DevicesTable.OrginalImg, DevicesCartTable.DeviceID FROM DevicesTable INNER JOIN DevicesCartTable ON DevicesTable.DeviceID = DevicesCartTable.DeviceID WHERE UserID="+UserID+" AND ArrivalTime <> #1/1/2001#";
        DataTable dt = Dbase.SelectFromTable(sql, "DB.accdb");
       
        
            return dt;
        
    }
    public static void DeleteByUserID(string UserID)
    {
        string SQL = "DELETE * FROM DevicesCartTable WHERE UserID=" + UserID;
        Dbase.ChangeTable(SQL, "DB.accdb");
    }
    public static void Delete(string DeviceID)
    {
        string SQL = "DELETE * FROM DevicesCartTable WHERE DeviceID=" + DeviceID;
        Dbase.ChangeTable(SQL, "DB.accdb");
    }
    public ClassDevicesCarts(string PurchaseID, string DeviceID, string UserID,string amount,string arrivalTime)
    {
        this.arrivalTime = arrivalTime;
        this.PurchaseID = PurchaseID;
        this.DeviceID = DeviceID;
        this.UserID = UserID;
        this.amount = amount;
    }
    public ClassDevicesCarts(string DeviceID, string UserID, string amount)
    {
        this.DeviceID = DeviceID;
        this.UserID = UserID;
        this.amount = amount;
    }
    public static bool DoesCartExist(string DeviceID, string UserID)
    {
        string sql = "SELECT * FROM DevicesCartTable WHERE DeviceID=" + DeviceID + " AND UserID=" + UserID +"AND ArrivalTime=#1/1/2001#";
        DataTable dt = Dbase.SelectFromTable(sql, "DB.accdb");
        return dt.Rows.Count > 0;
    }
    public static ClassDevicesCarts get(string DeviceID, string UserID)
    {
        string sql = "SELECT * FROM DevicesCartTable WHERE DeviceID=" + DeviceID + " AND UserID=" + UserID;
        DataTable dt = Dbase.SelectFromTable(sql, "DB.accdb");
        if(dt.Rows.Count==0)
        {
            return null;
        }
        return new ClassDevicesCarts(dt.Rows[0]["PurchaseID"].ToString(), DeviceID, UserID, dt.Rows[0]["amount"].ToString(), dt.Rows[0]["arrivalTime"].ToString());

    }

    public static void Delete(string DeviceID, string UserID)
    {
        string SQL = "DELETE * FROM DevicesCartTable WHERE DeviceID=" + DeviceID + " AND UserID=" + UserID;
        Dbase.ChangeTable(SQL, "DB.accdb");
    }
    public void Insert()
    {
        string SQL = "INSERT INTO DevicesCartTable ( DeviceID,UserID,ArrivalTime,amount) ";
        SQL += "VALUES('{0}', '{1}',#1/1/2001#,{2})";
        SQL = string.Format(SQL, DeviceID, UserID,amount);
        Dbase.ChangeTable(SQL, "DB.accdb");
    }
    public static void updateTime(string purchaseID,string Date)
    {
        string sql = "UPDATE DevicesCartTable SET ArrivalTime=#"+Date+"# WHERE PurchaseID = "+purchaseID;
        Dbase.ChangeTable(sql, "DB.accdb");
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for ClassCommentsDevice
/// </summary>
public class ClassCommentsDevice : GeneralASPClass
{
    public ClassCommentsDevice() : base("CommentsDeviceTable", "DB.accdb")
    {

    }
    public static DataTable GetDataTable(string DeviceID)
    {
        string sql = "SELECT UsersTable.UserName, CommentsDeviceTable.Content, CommentsDeviceTable.LikeCount, CommentsDeviceTable.CommentRating, CommentsDeviceTable.DislikeCount, CommentsDeviceTable.reportsCount, CommentsDeviceTable.Date, CommentsDeviceTable.CommentID FROM UsersTable INNER JOIN CommentsDeviceTable ON UsersTable.UserID = CommentsDeviceTable.CommenterUserID WHERE DeviceID="+DeviceID;
        return Dbase.SelectFromTable(sql, "DB.accdb");
    }
    
}
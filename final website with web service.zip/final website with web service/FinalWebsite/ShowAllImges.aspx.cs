﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ShowAllImges : System.Web.UI.Page
{
    public static string DeviceID;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                if (Session["LoggedInUser"] == null || bool.Parse(((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Isadmin")) == false)
                {
                    Session["Message"] = "please login as an admin";
                    Response.Redirect("Login.aspx");
                }
                if(Request.QueryString["Name"]==null|| Request.QueryString["DeviceID"]==null)
                {
                    Response.Redirect("GridViewOurDevices.aspx");
                }
                LabelName.Text ="Device Name = "+ Request.QueryString["Name"];
                DeviceID = Request.QueryString["DeviceID"];
                ShowImages();

            }
        }
        catch (Exception ex)
        {
            LabelMsg.Text = "ERORR in ShowAllImges::Page_Load=>" + ex.Message;
        }

    }
    private void ShowImages()
    {
        try
        {
            LabelMsg.Text = "";
            ClassImagesNameGUID cg = new ClassImagesNameGUID();
            DataTable DataTable1 = null;
            if (ViewState["Value"] == null || ViewState["Value"] as string == "")
            {
                string[] s1 = { "DeviceID" };
                string[] s2 = { DeviceID };
                DataTable1 = cg.getDataTableWhere(s1, s2);
            }
            else
            {
                string[] s1 = { "DeviceID", ViewState["ToSearch"]as string };
                string[] s2 = { DeviceID, ViewState["Value"] as string };
                DataTable1 = cg.getDataTableWhere(s1, s2);
            }
            if (DataTable1.Rows.Count < 1)
            {
                LabelMsg.Text = "You dont have any extra imges";

                object[] values = new object[DataTable1.Columns.Count];
                for (int i = 0; i < DataTable1.Columns.Count; i++)
                {
                    if (DataTable1.Columns[i].DataType.ToString().Equals("System.Int32"))
                    {
                        values[i] = default(System.Int32);
                    }
                    else if (DataTable1.Columns[i].DataType.ToString().Equals("System.String"))
                    {
                        values[i] = default(System.String);
                    }
                    else if (DataTable1.Columns[i].DataType.ToString().Equals("System.DateTime"))
                    {
                        values[i] = default(System.DateTime);
                    }
                    else if (DataTable1.Columns[i].DataType.ToString().Equals("System.Boolean"))
                    {
                        values[i] = default(System.Boolean);
                    }
                    else
                    {
                        values[i] = null;
                    }

                }
                DataTable1.Rows.Add(values);
                DataListImages.DataSource = DataTable1;
                DataListImages.DataBind();
                return;
            }
            DataListImages.DataSource = DataTable1;
            DataListImages.DataBind();
        }
        catch (Exception ex)
        {
            LabelMsg.Text = "ERROR in Cart::ShowImages=>" + ex.Message;

        }

    }

    protected void DataListImages_DeleteCommand(object source, DataListCommandEventArgs e)
    {
        try
        {
            ClassImagesNameGUID cg = new ClassImagesNameGUID();
            string[] s1 = { "GuidID" };
            string[] s2 = { e.CommandArgument as string };
            cg=(ClassImagesNameGUID)cg.completeObj(s1, s2);
            string path = Request.PhysicalApplicationPath;

            System.IO.File.Delete(path+cg.getAttributeByString("GUID"));
            cg.delete(s1, s2);
            ShowImages();
        }
        catch (Exception ex)
        {
            LabelMsg.Text = "ERROR in Cart::DataListImages_DeleteCommand=>" + ex.Message;

        }
    }

    protected void DataListImages_ItemCommand(object source, DataListCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Insert")
            {
                LabelMsg.Text = "";
                FileUpload f = null;
                if (e.Item.ItemType == ListItemType.Footer)
                {

                    f = (FileUpload)e.Item.FindControl("FileUploadImg");


                }
                if (!f.PostedFile.ContentType.Contains("image"))
                {
                    LabelMsg.Text = "this is not an img";
                    return;

                }
                else if (f.PostedFile.ContentLength > 100000000)
                {
                    LabelMsg.Text = "The size of the Img must be <= 100MB";
                    return;
                }
                ClassImagesNameGUID cg = new ClassImagesNameGUID();
                string[] s1 = { "ImageName", "GUID", "DeviceID" };
                Guid g = Guid.NewGuid();
                string[] s2 = { f.FileName, "Img\\" + g.ToString() + "." + (f.FileName.Split('.'))[1], DeviceID };
                cg.insert(s1, s2);
                string path = Request.PhysicalApplicationPath;
                f.SaveAs(path + "Img\\" + g.ToString() + "." + (f.FileName.Split('.'))[1]);
                ShowImages();
            }
        }
        catch(Exception ex)
        {
            LabelMsg.Text = "ERROR in Cart::DataListImages_ItemCommand=>" + ex.Message;

        }
    }

    protected void ButtonSearch_Click(object sender, EventArgs e)
    {
        try
        {

            if( DropDownList1.SelectedValue=="ID")
            {
                ViewState["ToSearch"] = "GuidID";
            }
            else
            {
                ViewState["ToSearch"] = "ImageName";
            }
            ViewState["Value"] = TextBoxValue.Text;
            ShowImages();
            
        }
        catch (Exception ex)
        {
            LabelMsg.Text = "ERROR in GridViewOurDevices::ButtonSearch_Click=> " + ex.Message;

        }
    }
}
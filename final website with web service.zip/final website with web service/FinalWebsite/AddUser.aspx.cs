﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

public partial class AddUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ClassCountry c = new ClassCountry();
                DropDownListCountry.DataSource = c.GetDtAttribute();
                DropDownListCountry.DataBind();
            }
        }
        catch(Exception ex)
        {
            LabelMessage.Text = "ERROR in AddUser::Page_Load=>" + ex.Message;

        }

    }

    protected void ButtonReset_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("AddUser.aspx");
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in AddUser::ButtonReset_Click=>" + ex.Message;
        }
    }

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["isValed"] != null && (bool)ViewState["isValed"] == false)
            {
                return;
            }
            LabelMessage.Text = "";


            Session["Code"] = GetCode(TextBoxEmail.Text).ToString();
            if (int.Parse((string)Session["Code"]) < 0)
            {
                LabelMessage.Text = "Error: Thats not a real email";
                return;
            }
            DateTime dt;
            if (!DateTime.TryParse(TextBoxDob.Text, out dt))
            {
                LabelMessage.Text = "Error: Dob is invalid";
                return;
            }
            if (Request.QueryString["Isadmin"] == null)
            {
                string[] s1 = { "FullName", "UserName","Country", "MyPassword", "IsFemale", "Dob", "Email", "Start_day", "Last_day", "Isbanned", "Visa", "Isadmin" };
                string[] s2 = { TextBoxFullName.Text, TextBoxUserName.Text, DropDownListCountry.Text, TextBoxMyPassword.Text, CheckBoxIsFemale.Checked.ToString(), dt.ToString(), TextBoxEmail.Text, DateTime.Now.ToShortDateString(), DateTime.Now.ToShortDateString(), "false", TextBoxVisa.Text, "false" };
                Session["s1"] = s1;
                Session["s2"] = s2;

               Response.Redirect("Verify.aspx");
            }
            else
            {
                string[] s1 = { "FullName", "UserName","Country", "MyPassword", "IsFemale", "Dob", "Email", "Start_day", "Last_day", "Isbanned", "Visa", "Isadmin" };
                string[] s2 = { TextBoxFullName.Text, TextBoxUserName.Text,DropDownListCountry.Text, TextBoxMyPassword.Text, CheckBoxIsFemale.Checked.ToString(), dt.ToString(), TextBoxEmail.Text, DateTime.Now.ToShortDateString(), DateTime.Now.ToShortDateString(), "false", TextBoxVisa.Text, "true" };
                Session["s1"] = s1;
                Session["s2"] = s2;

                Response.Redirect("Verify.aspx");
            }
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in AddUser::ButtonAdd_Click=>" + ex.Message;
        }
    }
    public static int GetCode(string E)
    {
        int num = 0;
        if (E.IndexOf('@') <= 0)
        {
            return -1;
        }
        if (E.IndexOf('.') <= 0)
        {
            return -1;
        }
        char[] ch = { '@', '.' };
        string[] S = E.Split(ch);
        for (int i = 0; i < S.Length; i++)
        {
            if (S[i] == "")
                return -1;
        }
        try
        {
            MailMessage message = new MailMessage();
            SmtpClient smtp = new SmtpClient();
            message.From = new MailAddress("new.eshop123@gmail.com");
            message.To.Add(new MailAddress(E));
            message.Subject = "Wellcome";
            Random R = new Random();
            num = R.Next(100000, 999999);
            message.Body = "Hello and wellcome to the new electronic store\nPlease enter this code " + num + " to verify you email";
            smtp.Port = 587;
            smtp.Host = "smtp.gmail.com"; //for gmail host  
            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential("new.eshop123@gmail.com", "Mma213461692");
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Send(message);
        }
        catch (Exception) { }
        return num;

    }

    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        try
        {
            ClassUsers obj = new ClassUsers();
            string[] s1 = { "UserName" };
            string[] s2 = { TextBoxUserName.Text };
            GeneralASPClass g = obj.completeObj(s1, s2);
            if (g != null)
            {
                args.IsValid = false;
                ViewState["isValed"] = false;
                return;
            }
            ViewState["isValed"] = true;
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in AddUser::CustomValidator1_ServerValidate=>"+ex.Message;
                ViewState["isValed"] = false;
        }
    }
}
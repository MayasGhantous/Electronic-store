﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class GridViewKinds : System.Web.UI.Page
{
   
   
    
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                LabelError.Text = "";
                if (Session["LoggedInUser"] == null || bool.Parse(((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Isadmin")) == false)
                {
                    Session["Message"] = "Please login as an admin";
                    Response.Redirect("Login.aspx");
                }
                ClassKind cu = new ClassKind();
                int i = 0;
                string s = cu.getAttributeName(i);
                while (s != "")
                {
                    if (s != "OrginalImg")
                    {
                        DropDownList1.Items.Add(s);
                    }
                    i++;
                    s = cu.getAttributeName(i);
                }
                FillGrid();
              


            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewOurDevices::FillGrid=> " + ex.Message;

        }
    }
    private void FillGrid(string Name = "", string value = "")
    {
        try
        {
            ClassKind cu = new ClassKind();
            DataTable dt = null;
            if (Name == "" || value == "" || value == null || Name == null)
            {
                dt = cu.GetDtAttribute();
                GridViewsUsers.DataSource = dt;
        
                GridViewsUsers.DataBind();
            }
            else
            {
                string[] s1 = { Name };
                string[] s2 = { value };
                dt = cu.getDataTableWhere(s1, s2);
                GridViewsUsers.DataSource = dt;
          
                GridViewsUsers.DataBind();
            }
            if (dt.Rows.Count == 0)
            {
                LabelError.Text = "You dont have and data";
                GeneralASPClass.ShowEmptyGridView(GridViewsUsers, dt);
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::FillGrid=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            GridViewsUsers.EditIndex = -1;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_RowCancelingEdit =>" + ex.Message;
        }
    }
    protected void GridViewsUsers_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            GridViewsUsers.EditIndex = e.NewEditIndex;
            string old_un = ((Label)GridViewsUsers.Rows[e.NewEditIndex].FindControl("LabelKind")).Text;
            Session["Kind"] = old_un;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_RowEditing:: " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {

            LabelError.Text = "";
            
            string Name = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxKind")).Text;
          
           
               string[] s1 = { "Kind", };
            string[] s2 = { Name };
            string[] s3 = { Session["Kind"].ToString() };
                ClassKind C = new ClassKind();
                C = (ClassKind)C.completeObj(s1, s2);
            if (Session["Kind"].ToString() == Name)
            {
                GridViewsUsers.EditIndex = -1;
            }
            else if (C == null)
            {
                C = new ClassKind();
                C.update(s1, s2, s1, s3);
                GridViewsUsers.EditIndex = -1;
            }
            else
            {
                LabelError.Text = "Kind is Already used";
                return;
            }
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);

        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_RowUpdating=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            string DI = ((Label)GridViewsUsers.Rows[e.RowIndex].FindControl("LabelKind")).Text;
            string[] s1 = { "Kind" };
            string[] s2 = { DI };
            ClassKind cd = new ClassKind();
            cd.delete(s1, s2);

            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_RowDeleting=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Insert")
            {
                ClassKind Device = new ClassKind();
                string Name = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewKind")).Text;
               
                string[] s1 = {"Kind"};
                string[] s2 = {Name };
                Device = (ClassKind)Device.completeObj(s1, s2);
                if (Device == null)
                {
                    Device = new ClassKind();
                    Device.insert(s1, s2);
                  
                    FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
                    LabelError.Text = "";
                }
                else
                {
                    LabelError.Text = "This Kind Already exists";
                    return;
                }


            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_RowCommand=> " + ex.Message;
        }
    }
  
  
    protected void GridViewsUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            GridViewsUsers.PageIndex = e.NewPageIndex;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewOurDevices::GridViewsUsers_PageIndexChanging=> " + ex.Message;

        }
    }


    protected void ButtonSearch_Click(object sender, EventArgs e)
    {
        try
        {

            ViewState["ToSearch"] = DropDownList1.SelectedValue;
            ViewState["Vlaue"] = TextBoxValue.Text;
            GridViewsUsers.PageIndex = 0;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewOurDevices::ButtonSearch_Click=> " + ex.Message;

        }
    }



   
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class GridVIewUsers : System.Web.UI.Page
{
    //public static string today()
    //{
    //    return DateTime.Now.ToShortDateString();
    //}
    //public static string getMinus18()
    //{
    //    return DateTime.Now.AddYears(-18).ToShortDateString();
    //}
    //public static string getMinus100()
    //{
    //    return DateTime.Now.AddYears(-100).ToShortDateString();
    //}
    public DataTable GVDataSource
    {
        get
        {
            if (ViewState["GVDataSource"] == null)
            {
                ViewState["GVDataSource"] = this.GridViewsUsers.DataSource as DataTable;
            }
            return ViewState["GVDataSource"] as DataTable;
        }
        set
        {
            ViewState["GVDataSource"] = value;
        }
    }
    public string SortExpression
    {
        get
        {
            if (ViewState["SortExpression"] == null)
            {
                ViewState["SortExpression"] = "Do Not Sort";
            }
            return ViewState["SortExpression"].ToString();
        }
        set
        {
            ViewState["SortExpression"] = value;
        }
    }
    public SortDirection GridViewSortDirection
    {
        get
        {
            if (ViewState["GridViewSortDirection"] == null)
            {
                ViewState["GridViewSortDirection"] = SortDirection.Ascending;
            }
            return (SortDirection)ViewState["GridViewSortDirection"];
        }
        set
        {
            ViewState["GridViewSortDirection"] = value;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LabelMessage.Text = "";
            LabelError.Text = "";
            if (!IsPostBack)
            {
                if (Session["LoggedInUser"] == null || bool.Parse(((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Isadmin")) == false)
                {
                    Session["Message"] = "Please login as an admin";
                    Response.Redirect("Login.aspx");
                }
              
              
            
                ClassUsers cu = new ClassUsers();
                int i = 0;
                string s = cu.getAttributeName(i);
                while (s != "")
                {
                    DropDownList1.Items.Add(s);
                    i++;
                    s = cu.getAttributeName(i);
                }
                FillGrid();

                LabelError.Text = "";
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridVIewUsers::FillGrid=> " + ex.Message;

        }
    }
    private void FillGrid(string Name = "", string value = "")
    {
        try
        {
            ClassUsers cu = new ClassUsers();
            DataTable dt = null;
            if (Name == "" || value == "" || value == null || Name == null)
            {
                dt = cu.GetDtAttribute();
                GridViewsUsers.DataSource = dt;
                GVDataSource = dt;
                GridViewsUsers.DataBind();
            }
            else
            {
                string[] s1 = { Name };
                string[] s2 = { value };
                dt = cu.getDataTableWhere(s1, s2);
                GridViewsUsers.DataSource = dt;
                GVDataSource = dt;
                GridViewsUsers.DataBind();
            }
            if (dt.Rows.Count == 0)
            {
                LabelError.Text = "You dont have and data";
                GeneralASPClass.ShowEmptyGridView(GridViewsUsers, dt);
            }


            ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewStart_day")).Text = DateTime.Now.ToShortDateString();
            ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewLast_day")).Text = DateTime.Now.ToShortDateString();
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridVIewUsers::FillGrid=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            GridViewsUsers.EditIndex = -1;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridVIewUsers::GridViewsUsers_RowCancelingEdit =>" + ex.Message;
        }
    }
    protected void GridViewsUsers_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            //string Dob = ((Label)GridViewsUsers.Rows[e.NewEditIndex].FindControl("LabelDob")).Text;
            //string Start_day = ((Label)GridViewsUsers.Rows[e.NewEditIndex].FindControl("LabelStart_day")).Text;
            //string Last_day = ((Label)GridViewsUsers.Rows[e.NewEditIndex].FindControl("LabelLast_day")).Text;

            LabelError.Text = "";
            GridViewsUsers.EditIndex = e.NewEditIndex;
            string old_un = ((Label)GridViewsUsers.Rows[e.NewEditIndex].FindControl("LabelUserName")).Text;
            Session["old_un"] = old_un;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);

            //  Dob = DateTime.Parse(Dob).ToShortDateString();
            //((TextBox)GridViewsUsers.Rows[e.NewEditIndex].FindControl("TextBoxDob")).Text = Dob;
            //((TextBox)GridViewsUsers.Rows[e.NewEditIndex].FindControl("TextBoxStart_day")).Text = DateTime.Parse(Start_day).ToShortDateString();
            //((TextBox)GridViewsUsers.Rows[e.NewEditIndex].FindControl("TextBoxLast_day")).Text = DateTime.Parse(Last_day).ToShortDateString();
            //   FillGrid();
            string UI = ((Label)GridViewsUsers.Rows[e.NewEditIndex].FindControl("LabelUserID")).Text;
            Session["Id"] = UI;
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridVIewUsers::GridViewsUsers_RowEditing:: " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            ClassUsers User = new ClassUsers();
            string UserName = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxUserName")).Text;
            string MyPassword = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxPassword")).Text;
            string FullName = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxFullName")).Text;
            string Email = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxEmail")).Text;
            string IsFemale = ((CheckBox)GridViewsUsers.Rows[e.RowIndex].FindControl("CheckBoxisFemale")).Checked.ToString();
            string Country = ((DropDownList)GridViewsUsers.Rows[e.RowIndex].FindControl("DropDownListCountry")).Text;
            string IsAdmin = ((CheckBox)GridViewsUsers.Rows[e.RowIndex].FindControl("CheckBoxisAdmin")).Checked.ToString();
            string UserId = Session["Id"].ToString();
            string Dob = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxDob")).Text;
            //  ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxDob")).Text=DateTime.Parse(Dob).ToShortDateString();
            string Start_day = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxStart_day")).Text;
            //    ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxStart_day")).Text = DateTime.Parse(Start_day).ToShortDateString();
            string Last_day = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxLast_day")).Text;
            //  ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxLast_day")).Text = DateTime.Parse(Last_day).ToShortDateString();

            string Visa = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxVisa")).Text;
            string IsBanned = true.ToString();//=((CheckBox)GridViewsUsers.FooterRow.FindControl("CheckBoxNewIsBanned")).Checked.ToString();
            DateTime SD1 = DateTime.Parse(Start_day);
            DateTime LD1 = DateTime.Parse(Last_day);

            if (SD1.CompareTo(DateTime.Now) == 0 && SD1.CompareTo(LD1) != 0)
            {
                IsBanned = true.ToString();
            }
            else
            if (SD1.CompareTo(DateTime.Now) != 0 && SD1.CompareTo(LD1) == 0)
            {
                IsBanned = false.ToString();
            }
            else if (SD1.CompareTo(DateTime.Now) > 0)
            {
                IsBanned = false.ToString();
            }
            string[] s1 = { "FullName", "UserName","Country", "MyPassword", "Dob", "IsFemale", "Email", "Start_day", "Last_day", "Isbanned", "Visa", "Isadmin" };
            string[] s2 = { FullName, UserName, Country, MyPassword, Dob, IsFemale, Email, Start_day, Last_day, IsBanned, Visa, IsAdmin };
            string[] s3 = { "UserID" };
            string[] s4 = { UserId };
            ClassUsers C = new ClassUsers();
            C = (ClassUsers)C.completeObj(s3, s4);
            if (Session["old_un"].ToString() == UserName)
            {
                C.update(s1, s2, s3, s4);
                GridViewsUsers.EditIndex = -1;
            }
            else if (C == null)
            {
                C.update(s1, s2, s3, s4);
                GridViewsUsers.EditIndex = -1;
            }
            else
            {
                LabelError.Text = "UserName is Already used";
            }
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);

        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridVIewUsers::GridViewsUsers_RowUpdating=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            string UI = ((Label)GridViewsUsers.Rows[e.RowIndex].FindControl("LabelUserID")).Text;
            ClassUsers Current = (ClassUsers)Session["LoggedInUser"];
            ClassUsers cu = new ClassUsers();
            string[] s1 = { "UserID" };
            string[] s2 = { UI };
            if (UI != Current.getAttributeByString("UserID"))
            {
                cu.delete(s1, s2);
                FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);

            }
            else
            {
                LabelError.Text = "Cant Delete The Current Logged In User";
            }


        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridVIewUsers::GridViewsUsers_RowDeleting=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Insert")
            {
                ClassUsers User = new ClassUsers();
                string UserName = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewUserName")).Text;
                string MyPassword = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewPassword")).Text;
                string FullName = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewFullName")).Text;
                string Email = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewEmail")).Text;
                string IsFemale = ((CheckBox)GridViewsUsers.FooterRow.FindControl("CheckBoxNewIsFemale")).Checked.ToString();
                string IsAdmin = ((CheckBox)GridViewsUsers.FooterRow.FindControl("CheckBoxNewIsAdmin")).Checked.ToString();
                string Country = ((DropDownList)GridViewsUsers.FooterRow.FindControl("DropDownListNewCountry")).Text;

                string Dob = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewDob")).Text;
                string Start_day = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewStart_day")).Text;
                string Last_day = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewLast_day")).Text;
                string Visa = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewVisa")).Text;
                string IsBanned = true.ToString();//=((CheckBox)GridViewsUsers.FooterRow.FindControl("CheckBoxNewIsBanned")).Checked.ToString();
                DateTime SD1 = DateTime.Parse(Start_day);
                DateTime LD1 = DateTime.Parse(Last_day);

                if (SD1.CompareTo(DateTime.Now) == 0 && SD1.CompareTo(LD1) != 0)
                {
                    IsBanned = true.ToString();
                }
                else
                if (SD1.CompareTo(DateTime.Now) != 0 && SD1.CompareTo(LD1) == 0)
                {
                    IsBanned = false.ToString();
                }
                else if (SD1.CompareTo(DateTime.Now) > 0)
                {
                    IsBanned = false.ToString();
                }
                string[] s1 = { "FullName", "UserName","Country", "MyPassword", "Dob", "IsFemale", "Email", "Start_day", "Last_day", "Isbanned", "Visa", "Isadmin" };
                string[] s2 = { FullName, UserName, Country, MyPassword, Dob, IsFemale, Email, Start_day, Last_day, IsBanned, Visa, IsAdmin };
                string[] s3 = { "UserName" };
                string[] s4 = { UserName };
                User = (ClassUsers)User.completeObj(s3, s4);
                if (User == null)
                {
                    User = new ClassUsers();
                    User.insert(s1, s2);
                    LabelError.Text = "";
                }
                else
                {
                    LabelError.Text = "This UserName Is Already Used";
                    return;
                }
                FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);

            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridVIewUsers::GridViewsUsers_RowCommand=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_Sorting(object sender, GridViewSortEventArgs e)
    {
        try
        {
            string strSortExpression = e.SortExpression;
            SortExpression = e.SortExpression;
            if (GridViewSortDirection == SortDirection.Ascending)
            {
                GridViewSortDirection = SortDirection.Descending;
                SortGridView(strSortExpression, "DESC");
            }
            else
            {
                GridViewSortDirection = SortDirection.Ascending;
                SortGridView(strSortExpression, "ASC");
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridVIewUsers::GridViewsUsers_Sorting=> " + ex.Message;

        }
    }
    private void SortGridView(string sortexpression, string direction)
    {
        try
        {
            if (GVDataSource == null)
                return;
            if (sortexpression == "Do Not Sort")
                return;
            DataView dv = new DataView(GVDataSource);
            dv.Sort = sortexpression + " " + direction;
            this.GridViewsUsers.DataSource = dv;
            GridViewsUsers.DataBind();
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridVIewUsers::SortGridView=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            GridViewsUsers.PageIndex = e.NewPageIndex;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
            if (GridViewSortDirection == SortDirection.Ascending)
            {
                SortGridView(SortExpression, "asc");
            }
            else
            {
                SortGridView(SortExpression, "desc");
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridVIewUsers::GridViewsUsers_PageIndexChanging=> " + ex.Message;

        }
    }
    public string GetSubDate(string s)
    {
        int er = s.IndexOf(" ");
        return s.Substring(0, s.IndexOf(" "));
    }

    protected void ButtonSearch_Click(object sender, EventArgs e)
    {
        try
        {
            ClassUsers cd = new ClassUsers();
            ViewState["ToSearch"] = DropDownList1.SelectedValue;
            ViewState["Vlaue"] = TextBoxValue.Text;
            if (cd.getTypeOf((string)ViewState["ToSearch"]).ToString().Equals("System.DateTime"))
            {
                DateTime dateTime;
                if (!DateTime.TryParse((string)ViewState["Vlaue"], out dateTime))
                {
                    LabelMessage.Text = "This is not a real date";
                    return;
                }
            }
            else if (cd.getTypeOf((string)ViewState["ToSearch"]).ToString().Equals("System.Boolean"))
            {
                bool dateTime;
                if (!bool.TryParse((string)ViewState["Vlaue"], out dateTime))
                {
                    LabelMessage.Text = "This is not a real boolean";
                    return;

                }
            }
            else if (cd.getTypeOf((string)ViewState["ToSearch"]).ToString().Equals("System.Int32"))
            {
                int dateTime;
                if (!int.TryParse((string)ViewState["Vlaue"], out dateTime))
                {
                    LabelMessage.Text = "This is not a real intger";
                    return;

                }
            }
            else
            {

                double dateTime;
                if (!double.TryParse((string)ViewState["Vlaue"], out dateTime))
                {
                    LabelMessage.Text = "This is not a real double";
                    return;

                }
            }
            GridViewsUsers.PageIndex = 1;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
            if (GridViewSortDirection == SortDirection.Ascending)
            {
                SortGridView(SortExpression, "asc");
            }
            else
            {
                SortGridView(SortExpression, "desc");
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridVIewUsers::ButtonSearch_Click=> " + ex.Message;

        }
    }

    protected void ButtonBanned_Click(object sender, EventArgs e)
    {
        try
        {
            ClassUsers.Banned();
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);

        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridVIewUsers::ButtonBanned_Click=> " + ex.Message;
        }
    }

    protected void ButtonCountry_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("GridViewCountryaspx.aspx");
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in ButtonCountry_Click::ButtonBanned_Click=> " + ex.Message;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for ClassKind
/// </summary>
public class ClassKind: GeneralASPClass
{
    //We need DT Kind
    //private static DataTable dtField = Dbase.SelectFromTable("SELECT * FROM DeviceKindTable", "DB.accdb");
    public ClassKind():base("DeviceKindTable", "DB.accdb")
    {
        //
        // TODO: Add constructor logic here
        //
    }
    //protected override void NameDataTable()
    //{
    //    dtAttribute.TableName = "DeviceKindTable";
    //}
    public static DataTable GetAllTheKindsAndFirst(string ID = "")
    {
        string SQL = "SELECT * FROM DeviceKindTable";
        DataTable dt = Dbase.SelectFromTable(SQL, "DB.accdb");
        if (ID == "")
        {
            return dt;
        }
        DataRow dr = null;
        for(int i = 0;i<dt.Rows.Count;i++)
        {
            if(dt.Rows[i]["Kind"].ToString()==ID)
            {
                dr = dt.Rows[i];
                break;
            }
        }
        if(dr==null)
        {
            return dt;
        }
        ///string tempID = dr["KindID"].ToString();
        string tempKind = dr["Kind"].ToString();
      //  dr["KindID"] = dt.Rows[0]["KindID"];
     //   dt.Rows[0]["KindID"] = tempID;
        dr["Kind"] = dt.Rows[0]["Kind"];
        dt.Rows[0]["Kind"] = tempKind;


        return dt;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ButtonReset_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("Login.aspx");
        }
        catch(Exception ex)
        {
            LabelMessage.Text = "ERORR in Login::ButtonReset_Click==>"+ex.Message;
        }
    }
    protected void ButtonLogin_Click(object sender, EventArgs e)
    {
        try
        {
            ClassUsers cu = new ClassUsers();
            string[] s1 = {"UserName","MyPassword" }; 
            string[] s2 = { TextBoxUserName.Text, TextBoxPassword.Text };
            Session["LoggedinUser"] = (ClassUsers)cu.completeObj(s1,s2);
            if (Session["LoggedinUser"] == null)
            {
                LabelMessage.Text = "Error: Not authorized to login!";
                TextBoxPassword.Text = "";
            }
            else if (bool.Parse(((ClassUsers)Session["LoggedinUser"]).getAttributeByString("Isbanned")))
            {
                Session["LoggedinUser"] = null;
                LabelMessage.Text = "Error: Your account has been banned";

            }
            else if (Request.QueryString["AddToCarToDeviceID"] != null)
            {
                Response.Redirect("ClickedDevice.aspx?DeviceID=" + Request.QueryString["AddToCarToDeviceID"]);
            }
            else
            {
                LabelMessage.Text = "";

                Response.Redirect("Default.aspx");
            }
        }
        catch(Exception ex)
        {
            LabelMessage.Text = "ERROR in Login::ButtonLogin_Click==>"+ex.Message;
        }
    }
    //protected void ButtonLogin_Click(object sender, EventArgs e)
    //{
    //    if (ClassUsers.DoesUserExist(TextBoxUserName.Text, TextBoxPassword.Text))
    //    {
    //        Session["LoggedIn"] = true;
    //        //Session["User"] = obj;
    //        Response.Redirect("Default.aspx");
    //    }
    //    else
    //    {
    //        Session["LoggedIn"] = false;
    //        LabelMessage.Text = "Error: Not authorized to login!";
    //    }
    //}
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ReportComment : System.Web.UI.Page
{
    private bool exist
    {
        get
        {
            return (bool)ViewState["exist"];
        }
        set
        {
            ViewState["exist"] = value;
        }
    }
    private string preReportID
    {
        get
        {
            if (ViewState["preReport"] != null)
                return (string)ViewState["preReport"];
            else
                return null;
        }
        set
        {
            ViewState["preReport"] = (string)value;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                if (Session["LoggedInUser"] == null)
                {
                    Session["Message"] = "Why do you want to report with out logging in? hmmm";
                    Response.Redirect("Login.aspx");
                }
                if (Request.QueryString["DeviceID"] == null)
                {
                    Session["Message"] = "How did you open this page?";
                    Response.Redirect("Default.aspx");
                }
                if (Request.QueryString["CommentID"] == null)
                {
                    Session["Message"] = "Hmm I see you want to find a bug";
                    Response.Redirect("Default.aspx");
                }
                exist = false;
                preReportID = "";
            }
        }
        catch (Exception ex)
        {
            LabelERROR.Text = "ERROR in ReportComment::Page_Load=> " + ex.Message;
        }
    }

    protected void ButtonCancel_Click(object sender, EventArgs e)
    {
        try
        {
            if (exist == false)
            {
                Response.Redirect("ClickedDevice.aspx?DeviceID=" + Request.QueryString["DeviceID"]);
            }
            else
            {
                ClassCommentsDevice ccd = new ClassCommentsDevice();
                string[] s5 = { "CommentID" };
                string[] s6 = { Request.QueryString["CommentID"] };
                ccd = (ClassCommentsDevice)ccd.completeObj(s5, s6);
                string[] s7 = { "reportsCount" };
                string[] s8 = { (int.Parse(ccd.getAttributeByString("reportsCount")) - 1).ToString() };
                ccd.update(s7, s8, s5, s6);
                string[] s1 = { "ReportID" };
                string[] s2 = { preReportID };
                ClassReport cp = new ClassReport();
                cp.delete(s1, s2);
                Response.Redirect("ClickedDevice.aspx?DeviceID=" + Request.QueryString["DeviceID"]);
            }
        }
        catch (Exception ex)
        {
            LabelERROR.Text = "ERROR in ReportComment::ButtonCancel_Click=> " + ex.Message;
        }
    }


    protected void ButtonSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (!exist)
            {
                string[] s3 = { "CommentID", "UserID" };
                string[] s4 = { Request.QueryString["CommentID"], ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID") };
                string[] s1 = { "CommentID", "Content", "UserID" };
                string[] s2 = { Request.QueryString["CommentID"], TextBoxContent.Text, ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID") };
                ClassReport cr = new ClassReport();
                cr = (ClassReport)cr.completeObj(s3, s4);
                if (cr == null)
                {
                    ClassCommentsDevice ccd = new ClassCommentsDevice();
                    string[] s5 = { "CommentID"};
                    string[] s6 = { Request.QueryString["CommentID"] };
                    ccd = (ClassCommentsDevice)ccd.completeObj(s5,s6);
                    string[] s7 = { "reportsCount"};
                    string[] s8 = {(int.Parse(ccd.getAttributeByString("reportsCount"))+1) .ToString()};
                    ccd.update(s7,s8,s5,s6);
                    cr = new ClassReport();
                    cr.insert(s1, s2);
                    Response.Redirect("ClickedDevice.aspx?DeviceID=" + Request.QueryString["DeviceID"]);
                }
                else
                {
                    LabelERROR.Text = "You allready reported this comment if you want to change click submit and if you want to delete it then click cancel";
                    preReportID = cr.getAttributeByString("ReportID") ;
                    exist = true;
                }
            }
            else
            {
                string[] s1 = { "CommentID", "Content", "UserID" };
                string[] s2 = { Request.QueryString["CommentID"], TextBoxContent.Text, ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID") };
                string[] s3 = { "ReportID" };
                string[] s4 = { preReportID };
                ClassReport cr = new ClassReport();
                cr.update(s1, s2, s3, s4);
                Response.Redirect("ClickedDevice.aspx?DeviceID=" + Request.QueryString["DeviceID"]);
            }

        }
        catch (Exception ex)
        {
            LabelERROR.Text = "ERROR in ReportComment::ButtonSubmit_Click=> " + ex.Message;
        }
    }
}
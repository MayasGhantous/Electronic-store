﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for ClassCountry
/// </summary>
public class ClassCountry:GeneralASPClass
{
    //we need get all
    public ClassCountry() : base("CountryTable","DB.accdb")
    {
    }
    public static DataTable GetAllTheCountryAndFirst(string ID = "")
    {
        string SQL = "SELECT * FROM CountryTable";
        DataTable dt = Dbase.SelectFromTable(SQL, "DB.accdb");
        if (ID == "")
        {
            return dt;
        }
        DataRow dr = null;
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            if (dt.Rows[i]["CountryName"].ToString() == ID)
            {
                dr = dt.Rows[i];
                break;
            }
        }
        if (dr == null)
        {
            return dt;
        }
        ///string tempID = dr["KindID"].ToString();
        string tempKind = dr["CountryName"].ToString();
        //  dr["KindID"] = dt.Rows[0]["KindID"];
        //   dt.Rows[0]["KindID"] = tempID;
        dr["CountryName"] = dt.Rows[0]["CountryName"];
        dt.Rows[0]["CountryName"] = tempKind;


        return dt;
    }
}
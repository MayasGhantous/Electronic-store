﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Delete : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LoggedInUser"] == null)
        {
            Response.Redirect("Login.aspx");
        }
    }

    protected void ButtonConfirm_Click(object sender, EventArgs e)
    {
        try
        {
            if (TextBoxPassword.Text == (Session["LoggedInUser"] as ClassUsers).getAttributeByString("MyPassword"))
            {

                string[] s1 = { "UserID" };
                string[] s2 = { ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID") };
                ClassUsers cu = new ClassUsers();
                cu.delete(s1, s2);
                Session["LoggedInUser"] = null;
                Session["Message"] = "Your account had been deleted";
                Response.Redirect("Default.aspx");
            }
            else
            {
                Session["Message"] = "The password is not correct";
                Response.Redirect("Delete.aspx");
            }
        }
        catch (Exception ex)
        {
            LabelErorr.Text = "ERORR in Delete::ButtonConfirm_Click=>" + ex.Message;
        }

    }

    protected void ButtonCancel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("Default.aspx");
        }
        catch (Exception ex)
        {
            LabelErorr.Text = "ERORR in Delete::ButtonCancel_Click=>" + ex.Message;
        }
    }
}
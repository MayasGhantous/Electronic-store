﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class GridviewAnswer : System.Web.UI.Page
{
   
    public DataTable GVDataSource
    {
        get
        {
            if (ViewState["GVDataSource"] == null)
            {
                ViewState["GVDataSource"] = this.GridViewsUsers.DataSource as DataTable;
            }
            return ViewState["GVDataSource"] as DataTable;
        }
        set
        {
            ViewState["GVDataSource"] = value;
        }
    }
    public string SortExpression
    {
        get
        {
            if (ViewState["SortExpression"] == null)
            {
                ViewState["SortExpression"] = "ASC";
            }
            return ViewState["SortExpression"].ToString();
        }
        set
        {
            ViewState["SortExpression"] = value;
        }
    }
    public SortDirection GridViewSortDirection
    {
        get
        {
            if (ViewState["GridViewSortDirection"] == null)
            {
                ViewState["GridViewSortDirection"] = SortDirection.Ascending;
            }
            return (SortDirection)ViewState["GridViewSortDirection"];
        }
        set
        {
            ViewState["GridViewSortDirection"] = value;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                if (Session["LoggedInUser"] == null || bool.Parse(((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Isadmin")) == false)
                {
                    Session["Message"] = "Please login as an admin";
                    Response.Redirect("Login.aspx");
                }
                FillGrid();
                LabelError.Text = "";
            }
        }
        catch(Exception ex)
        {
            LabelError.Text = "ERROR in GridviewAnswer::FillGrid=> " + ex.Message;

        }
    }
    private void FillGrid()
    {
        try
        {
            ClassFeadbacks cf = new ClassFeadbacks();
            DataTable dt = cf.GetDtAttribute();
            if(dt.Rows.Count==0)
            {
                LabelInfo.Text ="There is no feadbacks to answer";
            }
            
            GridViewsUsers.DataSource = dt;
            GVDataSource = dt;
            GridViewsUsers.DataBind();
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR inGridviewAnswer::FillGrid:: " + ex.Message;
        }
    }
   
   
    protected void GridViewsUsers_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
           
            LabelError.Text = "";
            Label ID = ((Label)GridViewsUsers.Rows[e.RowIndex].FindControl("LabelFeadbackID"));
            string[] s1 = { "FeadbackID"};
            string[] s2 = { ID.Text};
            ClassFeadbacks cf = new ClassFeadbacks();
            cf.delete(s1,s2);
            FillGrid();
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridviewAnswer::GridViewsUsers_RowDeleting:: " + ex.Message;
        }
    }
    
    protected void GridViewsUsers_Sorting(object sender, GridViewSortEventArgs e)
    {
        string strSortExpression = e.SortExpression;
        SortExpression = e.SortExpression;
        if (GridViewSortDirection == SortDirection.Ascending)
        {
            GridViewSortDirection = SortDirection.Descending;
            SortGridView(strSortExpression, "DESC");
        }
        else
        {
            GridViewSortDirection = SortDirection.Ascending;
            SortGridView(strSortExpression, "ASC");
        }
    }
    private void SortGridView(string sortexpression, string direction)
    {
        try
        {
            if (GVDataSource == null)
                return;
            DataView dv = new DataView(GVDataSource);
            dv.Sort = sortexpression + " " + direction;
            this.GridViewsUsers.DataSource = dv;
            GridViewsUsers.DataBind();
        }
        catch(Exception ex)
        {
            LabelError.Text = "ERROR in GridviewAnswer::SortGridView=>"+ex.Message;
        }
    }
    protected void GridViewsUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            GridViewsUsers.PageIndex = e.NewPageIndex;
            FillGrid();
            if (GridViewSortDirection == SortDirection.Ascending)
            {
                SortGridView(SortExpression, "asc");
            }
            else
            {
                SortGridView(SortExpression, "desc");
            }
        }
        catch(Exception ex)
        {
            LabelError.Text = "ERROR in GridviewAnswer::GridViewsUsers_PageIndexChanging=>" + ex.Message;

        }
    }
   
   
    //private int GetSortColumnIndex(string Col)
    //{
    //    foreach (DataControlField field in GridViewsUsers.Columns)
    //    {
    //        if (field.SortExpression == Col)
    //        {
    //            return GridViewsUsers.Columns.IndexOf(field);
    //        }
    //    }
    //    return -1;
    //}
}
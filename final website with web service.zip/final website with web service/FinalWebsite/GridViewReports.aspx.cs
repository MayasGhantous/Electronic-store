﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Windows.Forms.Design.Behavior;
//using System.Globalization;

public partial class GridViewReports : System.Web.UI.Page
{
    //public static string today()
    //{
    //    return DateTime.Now.ToShortDateString();
    //}
    //public static string getMinus18()
    //{
    //    return DateTime.Now.AddYears(-18).ToShortDateString();
    //}
    //public static string getMinus100()
    //{
    //    return DateTime.Now.AddYears(-100).ToShortDateString();
    //}
    public DataTable GVDataSource
    {
        get
        {
            if (ViewState["GVDataSource"] == null)
            {
                //string name = RegionInfo.CurrentRegion.DisplayName;
                ViewState["GVDataSource"] = this.GridViewsUsers.DataSource as DataTable;
            }
            return ViewState["GVDataSource"] as DataTable;
        }
        set
        {
            ViewState["GVDataSource"] = value;
        }
    }
    public string SortExpression
    {
        get
        {
            if (ViewState["SortExpression"] == null)
            {
                ViewState["SortExpression"] = "Do Not Sort";
            }
            return ViewState["SortExpression"].ToString();
        }
        set
        {
            ViewState["SortExpression"] = value;
        }
    }
    public SortDirection GridViewSortDirection
    {
        get
        {
            if (ViewState["GridViewSortDirection"] == null)
            {
                ViewState["GridViewSortDirection"] = SortDirection.Ascending;
            }
            return (SortDirection)ViewState["GridViewSortDirection"];
        }
        set
        {
            ViewState["GridViewSortDirection"] = value;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LabelMessage.Text = "";
            LabelError.Text = "";

            if (!IsPostBack)
            {
                if (Session["LoggedInUser"] == null || bool.Parse(((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Isadmin")) == false)
                {
                    Session["Message"] = "Please login as an admin";
                    Response.Redirect("Login.aspx");
                }
                string []s1={"UserID","CommentID" };
                GridViewsUsers.DataKeyNames = s1;
               int i = 0;
                string s = ClassReport.getAttributeNameInClass(i);
                while (s != "")
                {
                    if (s != "Content")
                    {
                        DropDownList1.Items.Add(s);
                    }
                    i++;
                    s = ClassReport.getAttributeNameInClass(i);
                }
                FillGrid();
               

            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewReports::FillGrid=> " + ex.Message;

        }
    }
    private void FillGrid(string Name = "", string value = "")
    {
        try
        {
            
            DataTable dt = null;
            if (Name == "" || value == "" || value == null || Name == null)
            {
                dt =ClassReport.getAllReportedComments();
                GridViewsUsers.DataSource = dt;
                GVDataSource = dt;
                GridViewsUsers.DataBind();
            }
            else
            {
            
                dt = ClassReport.getAllReportedComments(Name,value);
                GridViewsUsers.DataSource = dt;
                GVDataSource = dt;
                GridViewsUsers.DataBind();
            }
            if (dt.Rows.Count == 0)
            {
                LabelError.Text = "You dont have any data";
                GeneralASPClass.ShowEmptyGridView(GridViewsUsers, dt);
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewReports::FillGrid=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            GridViewsUsers.EditIndex = -1;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewReports::GridViewsUsers_RowCancelingEdit =>" + ex.Message;
        }
    }
    protected void GridViewsUsers_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            GridViewsUsers.EditIndex = e.NewEditIndex;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewReports::GridViewsUsers_RowEditing:: " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {

            LabelError.Text = "";
            int d = int.Parse(((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxTime")).Text);
            ClassUsers cu = new ClassUsers();
            string[] s1 = {"Isbanned", "Start_day","Last_day"};
            string[] s2 = {true.ToString(),DateTime.Now.ToShortDateString(),DateTime.Now.AddDays(d).ToShortDateString() };
            string[] s3 = { "UserID" };
            string [] s4 = { e.Keys["UserID"].ToString()};
            cu = (ClassUsers)cu.completeObj(s3,s4) ;
            if (!bool.Parse(cu.getAttributeByString("Isadmin")))
            {
                cu.update(s1, s2, s3, s4);
            }
            else
            {
                LabelError.Text = "You cant Banned an admin but the comment will be deleted";
            }
            s3[0] = "CommentID";
            s4[0] = e.Keys["CommentID"].ToString();
            ClassCommentsDevice ccd = new ClassCommentsDevice();
            ccd.delete(s3,s4);
            GridViewsUsers.EditIndex = -1;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);

        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewOurDevices::GridViewsUsers_RowUpdating=> " + ex.Message;
        }
    }
    
   
    protected void GridViewsUsers_Sorting(object sender, GridViewSortEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            string strSortExpression = e.SortExpression;
            SortExpression = e.SortExpression;
            if (GridViewSortDirection == SortDirection.Ascending)
            {
                GridViewSortDirection = SortDirection.Descending;
                SortGridView(strSortExpression, "DESC");
            }
            else
            {
                GridViewSortDirection = SortDirection.Ascending;
                SortGridView(strSortExpression, "ASC");
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewReports::GridViewsUsers_Sorting=> " + ex.Message;

        }
    }
    private void SortGridView(string sortexpression, string direction)
    {
        try
        {
            LabelError.Text = "";

            if (GVDataSource == null)
                return;
            if (sortexpression == "Do Not Sort")
                return;
            DataView dv = new DataView(GVDataSource);
            dv.Sort = sortexpression + " " + direction;
            this.GridViewsUsers.DataSource = dv;
            GridViewsUsers.DataBind();
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewOurDevices::SortGridView=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            LabelError.Text = "";

            GridViewsUsers.PageIndex = e.NewPageIndex;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
            if (GridViewSortDirection == SortDirection.Ascending)
            {
                SortGridView(SortExpression, "asc");
            }
            else
            {
                SortGridView(SortExpression, "desc");
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewReports::GridViewsUsers_PageIndexChanging=> " + ex.Message;

        }
    }


    protected void ButtonSearch_Click(object sender, EventArgs e)
    {
        try
        {
            LabelError.Text = "";
            ClassReport cd = new ClassReport();
            ViewState["ToSearch"] = DropDownList1.SelectedValue;
            ViewState["Vlaue"] = TextBoxValue.Text;
            if (cd.getTypeOf((string)ViewState["ToSearch"]).ToString().Equals("System.DateTime"))
            {
                DateTime dateTime;
                if (!DateTime.TryParse((string)ViewState["Vlaue"], out dateTime))
                {
                    LabelMessage.Text = "This is not a real date";
                    return;
                }
            }
            else if (cd.getTypeOf((string)ViewState["ToSearch"]).ToString().Equals("System.Boolean"))
            {
                bool dateTime;
                if (!bool.TryParse((string)ViewState["Vlaue"], out dateTime))
                {
                    LabelMessage.Text = "This is not a real boolean";
                    return;

                }
            }
            else if (cd.getTypeOf((string)ViewState["ToSearch"]).ToString().Equals("System.Int32"))
            {
                int dateTime;
                if (!int.TryParse((string)ViewState["Vlaue"], out dateTime))
                {
                    LabelMessage.Text = "This is not a real intger";
                    return;

                }
            }
            else
            {

                double dateTime;
                if (!double.TryParse((string)ViewState["Vlaue"], out dateTime))
                {
                    LabelMessage.Text = "This is not a real double";
                    return;

                }
            }
            GridViewsUsers.PageIndex = 0;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
            if (GridViewSortDirection == SortDirection.Ascending)
            {
                SortGridView(SortExpression, "asc");
            }
            else
            {
                SortGridView(SortExpression, "desc");
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewReports::ButtonSearch_Click=> " + ex.Message;

        }
    }



    protected void GridViewsUsers_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {


            if (e.CommandName == "Why")
            {
                Response.Redirect ("SeeWhy.aspx?CommentID="+e.CommandArgument);
            }
        }
        catch(Exception ex)
        {
            LabelError.Text = "ERROR in GridViewReports::GridViewsUsers_RowCommand=> " + ex.Message;

        }
    }
}
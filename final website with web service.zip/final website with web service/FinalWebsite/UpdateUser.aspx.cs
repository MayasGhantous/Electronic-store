﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UpdateUser : System.Web.UI.Page
{
    private static string OldUserName;
    private static string NewPassowrd;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LabelMessage.Text = "";
            if (!IsPostBack)
            {
                if (Session["LoggedinUser"] != null)
                {
                    ((ClassUsers)Session["LoggedinUser"]).getAttributeByString("UserID");
                    TextBoxUserID.Text = ((ClassUsers)Session["LoggedinUser"]).getAttributeByString("UserID");
                    TextBoxUserName.Text = ((ClassUsers)Session["LoggedinUser"]).getAttributeByString("UserName");
                    OldUserName = ((ClassUsers)Session["LoggedinUser"]).getAttributeByString("UserName");
                    TextBoxFullName.Text = ((ClassUsers)Session["LoggedinUser"]).getAttributeByString("FullName");
                    DateTime dt = DateTime.Parse(((ClassUsers)Session["LoggedinUser"]).getAttributeByString("Dob"));
                    TextBoxDob.Text = dt.ToShortDateString();
                    ClassCountry c = new ClassCountry();
                    DropDownListCountry.DataSource = c.GetDtAttribute();
                    DropDownListCountry.DataBind();
                    DropDownListCountry.SelectedValue = ((ClassUsers)Session["LoggedinUser"]).getAttributeByString("Country");
                    CheckBoxIsFemale.Checked = bool.Parse(((ClassUsers)Session["LoggedinUser"]).getAttributeByString("IsFemale"));
                    TextBoxEmail.Text = ((ClassUsers)Session["LoggedinUser"]).getAttributeByString("Email");
                    TextBoxVisa.Text = ((ClassUsers)Session["LoggedinUser"]).getAttributeByString("Visa");
                    TextBoxMyPassword.Text = ((ClassUsers)Session["LoggedinUser"]).getAttributeByString("MyPassword");
                }
                else
                {
                    Session["Message"] = "why didnt you log in?";
                    Response.Redirect("Login.aspx");
                }
            }
        }
        catch(Exception ex)
        {
            LabelMessage.Text = "ERORR in UpdateUser::Page_Load=>"+ex.Message;
        }
    }



   
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        try
        {
            ClassUsers obj = new ClassUsers();
            string[] s1 = { "UserName" };
            string[] s2 = { TextBoxUserName.Text };
            GeneralASPClass g = obj.completeObj(s1, s2);
            if (g != null && g.getAttributeByString("UserName") != OldUserName)
            {
                args.IsValid = false;
            
            }
          
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in AddUser::CustomValidator1_ServerValidate=>" + ex.Message;
                args.IsValid = false;

        }
    }

    protected void ButtonUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            Page.Validate();
            if (Page.IsValid == false)
            {
                ButtonCancel.Visible = false;
                ButtonConfirm.Visible = false;
                LabelFormerPassword.Visible = false;
                TextBoxMyPasswordLast.Visible = false;
                TextBoxMyPasswordLast.TextMode = TextBoxMode.SingleLine;
                TextBoxMyPasswordLast.Text = "oit";
                LabelFormerPassword.Visible = false;
                TextBoxFullName.Enabled = true;
                TextBoxUserName.Enabled = true;
                TextBoxEmail.Enabled = true;
                CheckBoxIsFemale.Enabled = true;
                TextBoxMyPassword.Enabled = true;
                TextBoxDob.Enabled = true;
                TextBoxVisa.Enabled = true;
                DropDownListCountry.Enabled = true;
                return;
            }
            else
            {
                ButtonCancel.Visible = true;
                ButtonConfirm.Visible = true;
                LabelFormerPassword.Visible = true;
                TextBoxMyPasswordLast.Visible = true;
                NewPassowrd = TextBoxMyPassword.Text.Trim(); 
                TextBoxMyPasswordLast.Text = "";
                TextBoxMyPasswordLast.TextMode = TextBoxMode.Password;
                LabelFormerPassword.Visible = true;
                TextBoxFullName.Enabled = false;
                TextBoxUserName.Enabled = false;
                TextBoxEmail.Enabled = false;
                CheckBoxIsFemale.Enabled = false;

                TextBoxMyPassword.Enabled = false;
                TextBoxDob.Enabled = false;
                TextBoxVisa.Enabled = false;
                DropDownListCountry.Enabled = false;

            }
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in UpdateUser::ButtonUpdate_Click=>" + ex.Message;
        }
        }

    protected void ButtonCancel_Click(object sender, EventArgs e)
    {
        try
        {
            LabelMessage.Text = "You have canceled the change";
            ButtonCancel.Visible = false;
            ButtonConfirm.Visible = false;
            LabelFormerPassword.Visible = false;
            TextBoxMyPasswordLast.Visible = false;
            TextBoxMyPasswordLast.TextMode = TextBoxMode.SingleLine;
            TextBoxMyPasswordLast.Text = "oit";
            LabelFormerPassword.Visible = false;
            TextBoxFullName.Enabled = true;
            TextBoxUserName.Enabled = true;
            TextBoxEmail.Enabled = true;
            CheckBoxIsFemale.Enabled = true;

            TextBoxMyPassword.Enabled = true;
            TextBoxDob.Enabled = true;
            TextBoxVisa.Enabled = true;
            DropDownListCountry.Enabled = true;
            return;
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in UpdateUser::ButtonCancel_Click=>" + ex.Message;
        }
    }

    protected void ButtonConfirm_Click(object sender, EventArgs e)
    {
        try
        {
            Page.Validate();
            if (Page.IsValid == false)
            {
                return;
            }
            DateTime dt;
            if (!DateTime.TryParse(TextBoxDob.Text, out dt))
            {
                LabelMessage.Text = "Error: Dob is invalid";
                return;
            }

            if (TextBoxMyPasswordLast.Text == ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("MyPassword"))
            {
                ClassUsers CU = new ClassUsers();
                string[] s1 = { "UserID" };
                string[] s2 = { ((ClassUsers)Session["LoggedinUser"]).getAttributeByString("UserID") };
                if (NewPassowrd != "")
                {
                    string[] s3 = { "FullName", "UserName","Country", "MyPassword", "Dob", "Visa", "Email", "IsFemale" };
                    string[] s4 = { TextBoxFullName.Text, TextBoxUserName.Text,DropDownListCountry.Text, NewPassowrd, TextBoxDob.Text, TextBoxVisa.Text, TextBoxEmail.Text, CheckBoxIsFemale.Checked.ToString() };
                    ClassUsers obj = new ClassUsers();
                    obj.update(s3, s4, s1, s2);
                    LabelMessage.Text = "Info: User updated successfully";
                }
                else
                {
                    string[] s3 = { "FullName", "UserName","Country", "Dob", "Visa", "Email", "IsFemale" };
                    string[] s4 = { TextBoxFullName.Text, TextBoxUserName.Text, DropDownListCountry.Text,TextBoxDob.Text, TextBoxVisa.Text, TextBoxEmail.Text, CheckBoxIsFemale.Checked.ToString() };
                    ClassUsers obj = new ClassUsers();
                    obj.update(s3, s4, s1, s2);
                    LabelMessage.Text = "Info: User updated successfully";
                }
                Session["LoggedinUser"] = CU.completeObj(s1,s2);
                Session["Message"] = "Info: User updated successfully";
                Response.Redirect("UpdateUser.aspx");

            }
            else
            {
                LabelMessage.Text = "Info: You didn't Enter the right password !!";
            }
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in UpdateUser::ButtonCancel_Click=>" + ex.Message;
        }
    }
}
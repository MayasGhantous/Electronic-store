﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ChangeTheForgtenPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ButtonDone_Click(object sender, EventArgs e)
    {
        try
        {

            if (ViewState["IsValid"] != null && (bool)ViewState["IsValid"] == false)
            {
                return;
            }

            ClassUsers CU = Session["HowForgotPassword"] as ClassUsers;
            string[] s1 = {"MyPassword" };
            string[] s2 = {TextBoxNewPassword.Text };
            string[] s3 = { "UserID" };
            string[] s4 = {CU.getAttributeByString("UserID") };
            CU.update(s1,s2,s3,s4);
            Response.Redirect("Login.aspx");

        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in Page_Load::ButtonDone_Click=>" + ex.Message;
        }
    }

    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        try
        {

            ClassUsers CU = Session["HowForgotPassword"] as ClassUsers;
            if(Session["HowForgotPassword"]==null)
            {
                Session["Message"] = "Nice Try";
                Response.Redirect("Default.aspx");
            }
            if (CU.getAttributeByString("MyPassword") == TextBoxNewPassword.Text)
            {
                args.IsValid = false;
                ViewState["IsValid"] = false;
                return;
            }
            ViewState["IsValid"] = true;

        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in Page_Load::ButtonDone_Click=>" + ex.Message;
            ViewState["IsValid"] = false;

        }
    }
}
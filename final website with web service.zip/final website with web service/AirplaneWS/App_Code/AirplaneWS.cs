﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;

/// <summary>
/// Summary description for AirplaneWS
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class AirplaneWS : System.Web.Services.WebService
{
  //  private static DataTable dt = Dbase.SelectFromTable("SELECT FlightID,MyTo,MyFrom From AirplanTable ORDER BY FlightDate DESC", "WSDB.accdb");

    public AirplaneWS()
    {
        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
        Remove();
       // dt = Dbase.SelectFromTable("SELECT FlightID,MyTo,MyFrom From AirplanTable ORDER BY FlightDate DESC", "WSDB.accdb");
    }
    public static void Remove()
    {
        string sql ="DELETE * FROM AirplanTable WHERE FlightDate < #"+DateTime.Now+"#";
        Dbase.ChangeTable(sql,"WSDB.accdb");
    }
    [WebMethod]
    public DataTable getFlightDescriptiion(string FlightsID, out DateTime ArrivingTime, out double PricePerKG)
    {
        ArrivingTime = new DateTime();
        PricePerKG = 0;
        if (FlightsID == "")
        {
            return null;
        }
        string sql = "SELECT * FROM AirplanTable WHERE FlightID = ";
        string[] id = FlightsID.Split(' ');
        int j = 0;
        for (j=0;j<id.Length-1;j++)
        {
            if(id[j]!="")
            sql += id[j] + " OR FlightID = ";
        }
        sql +=id[j];
        sql += " ORDER BY FlightDate ASC";
        DataTable dt = Dbase.SelectFromTable(sql,"WSDB.accdb");
         PricePerKG = 0;
        for (j = 0; j < dt.Rows.Count; j++)
        {
            PricePerKG += double.Parse(dt.Rows[j]["PricePerKG"].ToString());
        }
         ArrivingTime = DateTime.Parse(dt.Rows[j-1]["FlightDate"].ToString()).AddHours(double.Parse(dt.Rows[j-1]["FlightDuration"].ToString()));
        dt.TableName = "FlightsDeatels";
        return dt;
    }
    [WebMethod]
    public DataTable getAllFromTo(string From, string To)
    {
        if(From == To)
        {
            return null;
        }
        ArrayList s = new ArrayList();
        int i = 0;
        string s1 = "", s2 = "";
        fillNode(s,DateTime.Now,0, s1, s2, From, To, 4);
        if(s.Count==0)
        {
            return null;
        }
        DataTable dt = new DataTable();
        dt.Columns.Add("ID", Type.GetType("System.Int32"));
        dt.Columns.Add("Flight",Type.GetType("System.String"));
        for (int j = 0; j < s.Count; j++)
        {
            dt.Rows.Add(j, s[j]);
        }
        dt.TableName = "FlightsTable";
        return dt;
    }
    private static void fillNode(ArrayList s,DateTime Date,double duration, string currentTarvel, string currentCounties, string From, string To, int max)
    {
        if (max == -1)
        {
            return;
        }
        if (From.ToUpper().Equals(To.ToUpper()))
        {
            s.Add(currentTarvel);
            return;
        }
        if (currentCounties.ToUpper().Contains(From.ToUpper()))
        {
            return;
        }

        DataTable dt = Dbase.SelectFromTable("SELECT MyFrom,FlightID,MyTo,FlightDate,FlightDuration FROM AirplanTable WHERE FlightDate >= #" + Date.AddHours(duration)+"#", "WSDB.accdb");
        for (int j = 0; j < dt.Rows.Count; j++)
        {
            if (dt.Rows[j]["MyFrom"].ToString().ToUpper().Equals(From.ToUpper()) &&
                !currentCounties.ToUpper().Contains(dt.Rows[j]["MyFrom"].ToString().ToUpper()))
            {
                currentTarvel += " " + dt.Rows[j]["FlightID"];
                currentCounties += " " + dt.Rows[j]["MyFrom"];

                fillNode(s,DateTime.Parse(dt.Rows[j]["FlightDate"].ToString()), double.Parse(dt.Rows[j]["FlightDuration"].ToString()), currentTarvel, currentCounties, dt.Rows[j]["MyTo"].ToString(), To, max - 1);
                currentCounties = currentCounties.Substring(0, currentCounties.LastIndexOf(" "));
                currentTarvel = currentTarvel.Substring(0, currentTarvel.LastIndexOf(" "));
            }
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class GridViewCountryaspx : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                if (Session["LoggedInUser"] == null || bool.Parse(((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Isadmin")) == false)
                {
                    Session["Message"] = "Please login as an admin";
                    Response.Redirect("Login.aspx");
                }
                ClassCountry cu = new ClassCountry();
                int i = 0;
                string s = cu.getAttributeName(i);
                while (s != "")
                {
                    if (s != "OrginalImg")
                    {
                        DropDownList1.Items.Add(s);
                    }
                    i++;
                    s = cu.getAttributeName(i);
                }
                FillGrid();
               


            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewCountryaspx::Page_Load=> " + ex.Message;

        }
    }
    private void FillGrid(string Name = "", string value = "")
    {
        try
        {
            ClassCountry cu = new ClassCountry();
            DataTable dt = null;
            if (Name == "" || value == "" || value == null || Name == null)
            {
                dt = cu.GetDtAttribute();
                GridViewsUsers.DataSource = dt;

                GridViewsUsers.DataBind();
            }
            else
            {
                string[] s1 = { Name };
                string[] s2 = { value };
                dt = cu.getDataTableWhere(s1, s2);
                GridViewsUsers.DataSource = dt;

                GridViewsUsers.DataBind();
            }
            if (dt.Rows.Count == 0)
            {
                LabelError.Text = "You dont have and data";
                GeneralASPClass.ShowEmptyGridView(GridViewsUsers, dt);
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewCountryaspx::FillGrid=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            GridViewsUsers.EditIndex = -1;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewCountryaspx::GridViewsUsers_RowCancelingEdit =>" + ex.Message;
        }
    }
    protected void GridViewsUsers_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            GridViewsUsers.EditIndex = e.NewEditIndex;
            string old_un = ((Label)GridViewsUsers.Rows[e.NewEditIndex].FindControl("LabelCountryName")).Text;
            Session["CountryName"] = old_un;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewCountryaspx::GridViewsUsers_RowEditing:: " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {

            LabelError.Text = "";

            string Name = ((TextBox)GridViewsUsers.Rows[e.RowIndex].FindControl("TextBoxCountryName")).Text;


            string[] s1 = { "CountryName" };
            string[] s2 = { Name };
            string[] s3 = { Session["CountryName"].ToString() };
            ClassCountry C = new ClassCountry();
            C = (ClassCountry)C.completeObj(s1, s2);
            if (Session["CountryName"].ToString() == Name)
            {
                GridViewsUsers.EditIndex = -1;
            }
            else if (C == null)
            {
                C = new ClassCountry();
                C.update(s1, s2, s1, s3);
                GridViewsUsers.EditIndex = -1;
            }
            else
            {
                LabelError.Text = "CountryName is Already used";
                return;
            }
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);

        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewCountryaspx::GridViewsUsers_RowUpdating=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            LabelError.Text = "";
            string DI = ((Label)GridViewsUsers.Rows[e.RowIndex].FindControl("LabelCountryName")).Text;
            if (DI == ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country")) ;
            {
                LabelError.Text = "Cant Delete the CurrentUser Country";
                return;
            }
            string[] s1 = { "CountryName" };
            string[] s2 = { DI };
            ClassCountry cd = new ClassCountry();
            cd.delete(s1, s2);

            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewCountryaspx::GridViewsUsers_RowDeleting=> " + ex.Message;
        }
    }
    protected void GridViewsUsers_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Insert")
            {
                ClassCountry Device = new ClassCountry();
                string Name = ((TextBox)GridViewsUsers.FooterRow.FindControl("TextBoxNewCountryName")).Text;

                string[] s1 = { "CountryName" };
                string[] s2 = { Name };
                Device = (ClassCountry)Device.completeObj(s1, s2);
                if (Device == null)
                {
                    Device = new ClassCountry();
                    Device.insert(s1, s2);

                    FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
                    LabelError.Text = "";
                }
                else
                {
                    LabelError.Text = "This CountryName Already exists";
                    return;
                }


            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERORR in GridViewCountryaspx::GridViewsUsers_RowCommand=> " + ex.Message;
        }
    }


    protected void GridViewsUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            GridViewsUsers.PageIndex = e.NewPageIndex;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewCountryaspx::GridViewsUsers_PageIndexChanging=> " + ex.Message;

        }
    }


    protected void ButtonSearch_Click(object sender, EventArgs e)
    {
        try
        {

            ViewState["ToSearch"] = DropDownList1.SelectedValue;
            ViewState["Vlaue"] = TextBoxValue.Text;
            GridViewsUsers.PageIndex = 0;
            FillGrid(ViewState["ToSearch"] as string, ViewState["Vlaue"] as string);
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in GridViewCountryaspx::ButtonSearch_Click=> " + ex.Message;

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for ClassImagesNameGUID
/// </summary>
public class ClassImagesNameGUID : GeneralASPClass
{
    public ClassImagesNameGUID() : base("ImagesNameGUIDTable", "DB.accdb")
    {
        //
        // TODO: Add constructor logic here
        //
    }
   
    public static string getAllAdditionalImges(string DeviceID)
    {
        string sql = "SELECt * FROM ImagesNameGUIDTable WHERE DeviceID = " + DeviceID;
        DataTable dt1 = Dbase.SelectFromTable(sql, "DB.accdb");
        string html = "";
        ClassDevices cd = new ClassDevices();
        string[] s1 = { "DeviceID" };
        string[] s2 = { DeviceID };
        cd = (ClassDevices)cd.completeObj(s1, s2);
        html += "  <img class=\"thumbnail active\" src=\""+cd.getAttributeByString("OrginalImg")+"\">";

        for (int i = 0; i < dt1.Rows.Count; i++)
        {
            html += "  <img class=\"thumbnail\" src=\""+dt1.Rows[i]["GUID"]+"\">";
        }
        //html += "<a class=\"prev\" onclick=\"plusSlides(-1)\">&#10094;</a>< a class=\"next\" onclick=\"plusSlides(1)\">&#10095;</a>";
        //html += "<div class=\"caption - container\">< p id = \"caption\" ></ p ></ div >";
        //html += "<div class=\"row\">";
        //html += "<div class=\"column\">< img class=\"demo cursor\" src=\"" + cd.getAttributeByString("OrginalImg") + "\" style=\"width:50px\" onclick=\"currentSlide(1)\"></div>";
        //for (int i = 0; i < dt1.Rows.Count; i++)
        //{
        //html += "<div class=\"column\">< img class=\"demo cursor\" src=\"" + dt1.Rows[i]["GUID"] + "\" style=\"width:50px\" onclick=\"currentSlide("+1+dt1.Rows.Count+")\"></div>";
        //}
        //html += "</div></div></div>";
        return html;
    }
}
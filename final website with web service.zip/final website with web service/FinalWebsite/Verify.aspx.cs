﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GotTheCode : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                if (Session["code"] == null)
                {
                    Response.Redirect("Login.aaspx");
                }
            }
        }
        catch(Exception ex)
        {
            LabelMessage.Text = "ERROR in GotTheCode::Page_Load=> "+ex.Message;
        }
    }

    protected void ButtonConfirm_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["To_Password"] == null || (bool)Session["To_Password"] == false)
            {
                if (TextBoxCode.Text == (string)Session["Code"])
                {
                    ClassUsers obj = new ClassUsers();
                    obj.insert(Session["s1"] as string[], Session["s2"] as string[]);
                    Response.Redirect("Login.aspx");
                }
                else
                {
                    Session["Message"] = "The Code Is Not Correct";
                    Response.Redirect("Verify.aspx");
                }
            }
            else
            {
                if (TextBoxCode.Text == (string)Session["Code"])
                {
                    Session["To_Password"] = false;
                    Response.Redirect("ChangeTheForgtenPassword.aspx");
                }
                else
                {
                    Session["Message"] = "The Code Is Not Correct";
                    Response.Redirect("Verify.aspx");
                }

            }
        }
        catch(Exception ex)
        {
            LabelMessage.Text = "ERORR in Verify::ButtonConfirm_Click==>"+ex.Message;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Web.UI.WebControls;

public partial class ShowArrivalTime : System.Web.UI.Page
{
    int length
    {
        set
        {
            ViewState["legnth"] = value;
        }
        get
        {
            return (int)ViewState["legnth"];
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["LoggedInUser"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                if (!IsPostBack)
                {
                    ShowDataList();
                }
                // LabelCartTable.Text = ClassDevicesCarts.GetAllAsHTMLTable((Session["LoggedInUser"] as ClassUsers).UserID);
            }
        }
        catch (Exception ex)
        {
            LabelMsg.Text = "ERROR in ShowArrivalTime::Page_Load=>" + ex.Message;
        }
    }
    private void ShowDataList()
    {
        try
        {
            DataTable dt = ClassDevicesCarts.getpurchases(((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"));
            if (dt.Rows.Count == 0)
            {
                LabelMsg.Text = "you dont have any thing to wait for";
            }
            length = dt.Rows.Count;
            DataListImages.DataSource = dt;
            DataListImages.DataBind();
        }
        catch (Exception ex)
        {
            LabelMsg.Text = "ERROR in ShowArrivalTime::ShowDataList=>" + ex.Message;

        }
    }
    public bool getArrival(object obj)
    {
        try
        {
            DateTime date = (DateTime)obj;
            if (DateTime.Now < date)
            {
                return false;
            }
            return true;
        }
        catch(Exception ex)
        {
            LabelMsg.Text = "ERROR in ShowArrivalTime::ShowDataList=>" + ex.Message;
            return false;
        }
    }
    public string getTime(object obj)
    {
        try
        {
            DateTime date = (DateTime)obj;

            string s1 = date.ToString();
            string s = date.Year + "/" + date.Month + "/" + date.Day + " " + date.Hour + ":" + date.Minute + ":" + date.Second;
            //string s = "2022/5/4 12:00:00 pm";
            return s;
            // return "2022/05/04 12:00 pm";
        }
        catch(Exception ex)
        {

            LabelMsg.Text = "ERROR in ShowArrivalTime::getTime=>" + ex.Message;
            return "";
        }
    }

    protected void DataListImages_DeleteCommand(object source, DataListCommandEventArgs e)
    {
        try
        {
            ClassDevicesCarts.DeleteById(e.CommandArgument.ToString());
            ShowDataList();
        }
        catch(Exception ex)
        {
            LabelMsg.Text = "ERROR in ShowArrivalTime::DataListImages_DeleteCommand=>" + ex.Message;
        }
    }
}
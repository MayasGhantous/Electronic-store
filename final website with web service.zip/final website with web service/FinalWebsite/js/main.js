﻿

$("#getting-started")
    .countdown("2022/05/04 12:00 pm", function (event) {
        $('#anything').text(
            event.strftime('%D:%H:%M:%S')
        );
    });

$('div#clock').countdown(finalDate, { elapse: false })
    .on('update.countdown', function (event) {
        if (event.elapsed) { // Either true or false
            // Counting up...
        } else {
            // Countdown...
        }
    });

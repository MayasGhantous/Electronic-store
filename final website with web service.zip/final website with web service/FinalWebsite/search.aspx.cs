﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using com.currencysystem.fx;

public partial class search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                string[] s1 = {"Name" };
                string[] s2 = { TextBoxSearch.Text};
                ClassDevices ccd = new ClassDevices();
                DataList1.DataSource = ccd.getDataTableWhere(s1,s2);
                DataList1.DataBind();
            }
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERORR in search::Page_Load=>" + ex.Message;
        }
    }

    protected void TextBoxSearch_TextChanged(object sender, EventArgs e)
    {
        try
        {
            string[] s1 = { "Name" };
            string[] s2 = { TextBoxSearch.Text };
            ClassDevices ccd = new ClassDevices();
            DataList1.DataSource = ccd.getDataTableWhere(s1, s2);
            DataList1.DataBind();
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERORR in search::TextBoxSearch_TextChanged=>" + ex.Message;
        }
    }
    public string getPrice(object price)
    {
        try
        {
            string s = price.ToString();
            CurrencyServer currency = new CurrencyServer();
            string name = RegionInfo.CurrentRegion.DisplayName;
            if (Session["LoggedInUser"] == null)
                return currency.ConvertToNum("", "USD", currency.CountryToCurrency("", name, true), double.Parse(s), true, "", "") + " " + currency.CurrencySymbol("", currency.CountryToCurrency("", name, true), "");
            else
            {
                return currency.ConvertToNum("", "USD", currency.CountryToCurrency("", ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country"), true), double.Parse(s), true, "", "") + " " + currency.CurrencySymbol("", currency.CountryToCurrency("", ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country"), true), "");

            }
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERROR in search::getPrice=> " + ex.Message;
        }
        return "";
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using com.currencysystem.fx;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            DataList1.DataSource = ClassDevices.getDeviceAbove("6");
            DataList1.DataBind();
        }
        catch(Exception ex)
        {
            LabelError.Text = "ERORR in _Default::Page_Load=>"+ex.Message;
        }
    }
    public string getPrice(object price)
    {
        try
        {
            string s = price.ToString();
            CurrencyServer currency = new CurrencyServer();
            string name = RegionInfo.CurrentRegion.DisplayName;
            if (Session["LoggedInUser"] == null)
                return currency.ConvertToNum("", "USD", currency.CountryToCurrency("", name, true), double.Parse(s), true, "", "") + " " + currency.CurrencySymbol("", currency.CountryToCurrency("", name, true), "");
            else
            { 
                return currency.ConvertToNum("", "USD", currency.CountryToCurrency("", ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country"), true), double.Parse(s), true, "", "") + " " + currency.CurrencySymbol("", currency.CountryToCurrency("", ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country"), true), "");

            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in Devices::getPrice=> " + ex.Message;
        }
        return "";
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Cart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["LoggedInUser"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                if (!IsPostBack)
                {
                    ShowImages();
                }
                // LabelCartTable.Text = ClassDevicesCarts.GetAllAsHTMLTable((Session["LoggedInUser"] as ClassUsers).UserID);
            }
        }
        catch(Exception ex)
        {
            LabelMsg.Text = "ERROR in Cart::Page_Load=>"+ex.Message;
        }
    }
    private void ShowImages()
    {
        try
        {
            DataTable dt = ClassDevicesCarts.GetDevices(((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"));
            if (dt == null)
            {
                LabelMsg.Text = "you didn't add to the cart anything";
                return;
            }
            DataListImages.DataSource = dt;
            DataListImages.DataBind();
        }
        catch (Exception ex)
        {
            LabelMsg.Text = "ERROR in Cart::ShowImages=>" + ex.Message;

        }

    }

    protected void DataListImages_DeleteCommand(object source, DataListCommandEventArgs e)
    {
        try
        {
            ClassDevicesCarts.Delete((string)e.CommandArgument,((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"));
            ShowImages();
        }
        catch(Exception ex)
        {
            LabelMsg.Text = "ERROR in Cart::DataListImages_DeleteCommand=>"+ex.Message;
               
        }
    }
}
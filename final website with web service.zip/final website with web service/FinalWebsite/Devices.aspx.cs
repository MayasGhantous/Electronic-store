﻿using com.currencysystem.fx;
using System;
using System.Globalization;

public partial class Devices : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Labeltable.Text = ClassDevices.GetAllAsHTMLTableByType(DropDownListType.SelectedValue.ToString());
        try
        {
            if (!IsPostBack)
            {

                ClassKind ck = new ClassKind();
                DropDownListType.DataSource = ck.GetDtAttribute();
                DropDownListType.DataBind();
                DataList1.DataSource = ClassDevices.getAvailabelDevices(DropDownListType.Text);
                DataList1.DataBind();
            }
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in Devices::Page_Load=>" + ex.Message;
        }
    }



    protected void DropDownListType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataList1.DataSource = ClassDevices.getAvailabelDevices(DropDownListType.Text, TextBoxPrice.Text, TextBoxRate.Text);
            DataList1.DataBind();
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in Devices::DropDownListType_SelectedIndexChanged=>" + ex.Message;

        }
    }


    protected void ButtonSearch_Click(object sender, EventArgs e)
    {
        try
        {
            DataList1.DataSource = ClassDevices.getAvailabelDevices(DropDownListType.Text, TextBoxPrice.Text, TextBoxRate.Text);
            DataList1.DataBind();
        }
        catch (Exception ex)
        {
            LabelError.Text = "ERROR in Devices::ButtonSearch_Click=>" + ex.Message;

        }
    }
    public string getPrice(object price)
    {
        try
        {
            string s = price.ToString();
            CurrencyServer currency = new CurrencyServer();
            string name = RegionInfo.CurrentRegion.DisplayName;
            if (Session["LoggedInUser"] == null)
                return currency.ConvertToNum("", "USD", currency.CountryToCurrency("", name, true), double.Parse(s), true, "", "") + " " + currency.CurrencySymbol("", currency.CountryToCurrency("", name, true), "");
            else
            {
                return currency.ConvertToNum("", "USD", currency.CountryToCurrency("", ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country"), true), double.Parse(s), true, "", "") + " " + currency.CurrencySymbol("", currency.CountryToCurrency("", ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country"), true), "");

            }
        }
        catch(Exception ex)
        {
            LabelError.Text = "ERROR in Devices::getPrice=> " + ex.Message;
        }
        return "";
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;

/// <summary>
/// Summary description for ClassUser
/// </summary>
public class GeneralASPClass
{
    protected string[] attributes;
    protected DataTable dtAttribute;
    protected string DBName;
    public GeneralASPClass(string DataTableName,string DBName)
    {
        this.dtAttribute = Dbase.SelectFromTable("SELECT * FROM "+DataTableName,DBName);
        this.dtAttribute.TableName = DataTableName;
        attributes = new string[dtAttribute.Columns.Count];
        this.DBName = DBName;
        //NameDataTable();
    }
    //public GeneralASPClass(DataTable dtAttribute, string DBName)
    //{
    //    attributes = new string[dtAttribute.Columns.Count];
    //    this.DBName = DBName;
    //    this.dtAttribute = dtAttribute;
    //    NameDataTable();
    //}
    //protected abstract void NameDataTable();
    public string getAttributeName(int i)
    {
        if (i < dtAttribute.Columns.Count&&i>=0)
            return dtAttribute.Columns[i].ColumnName;
        else
            return "";
    }
    public DataTable GetDtAttribute()
    {
        DataTable dt = Dbase.SelectFromTable("SELECT * FROM "+ dtAttribute.TableName, DBName);
        return dt;
    }
    public virtual string GetAllAsHtmlTable(string[] WhatTOGet = null, string[] attributesName = null, string[] values = null, int n = 0)
    {
        if (attributesName == null && values != null || attributesName != null && values == null)
        {
            throw new Exception("Using null pointer");
        }
        string sql;
        if (values == null)
        {
            sql = "SELECT * FROM " + dtAttribute.TableName;
        }
        else if (n == 0)
        {
            sql = getFindByEqualsSQL(dtAttribute, attributesName, values);
        }
        else
            sql = getFindByLikeSQL(dtAttribute, attributesName, values);
        DataTable dt = Dbase.SelectFromTable(sql, DBName);
        string table = "<table border=1>";
        table += "<tr>";
        for (int i = 0;WhatTOGet==null&& i < attributes.Length||WhatTOGet!=null && i < WhatTOGet.Length; i++)
        {
            table += "<td>";
            if (WhatTOGet != null)
                table += WhatTOGet[i];
            else
                table += dt.Columns[i].ColumnName;

            table += "</td>";
        }
        table += "</tr>";

        if (dt.Rows.Count == 0)
        {
            table += "<tr>";
            table += "<td align=center colspan=" + dt.Columns.Count + ">";
            table += "There is no data currently";
            table += "</td>";
            table += "</tr>";
            table += "</table>";
            return table;
        }
        // For each DataTable row create an HTML row and copy its data
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            table += "<tr>";

            if (WhatTOGet != null)
            {
                for (int j = 0; j < WhatTOGet.Length; j++)
                {
                    table += "<td>";

                    table += dt.Rows[i][WhatTOGet[j]].ToString();

                    table += "</td>";
                }
            }
            else
            {
                for (int j = 0; j < attributes.Length; j++)
                {
                    table += "<td>";
                    table += dt.Rows[i][dt.Columns[j].ColumnName].ToString();
                    table += "</td>";
                }
            }
            table += "</tr>";
        }
        table += "</table>";
        return table;

    }
    public void delete(string[] attributesNames, string[] values)
    {
        string s = getDeleteSQL(dtAttribute, attributesNames, values);
        Dbase.ChangeTable(s, DBName);
    }
    public void insert(string[] attributesNames, string[] values)
    {
        Dbase.ChangeTable(getInsertSQL(dtAttribute, attributesNames, values), DBName);
    }
    public GeneralASPClass completeObj(string[] attributesNames, string[] values)
    {
        string SQL = getFindByEqualsSQL(dtAttribute, attributesNames, values);
        DataTable dt = Dbase.SelectFromTable(SQL, DBName);
        if (dt.Rows.Count < 1)
        {
            return null;
        }
        for (int i = 0; i < dt.Columns.Count; i++)
        {
            attributes[i] = dt.Rows[0][i].ToString();
        }
        return this;
    }
    public DataTable getDataTableWhere(string[] attributesNames, string[] values)
    {
        string SQL = getFindByEqualsSQL(dtAttribute, attributesNames, values);
        DataTable dt = Dbase.SelectFromTable(SQL, DBName);
        return dt;
    }
    public string getAttributeByString(string attribute)
    {
        return attributes[dtAttribute.Columns.IndexOf(attribute)];
    }
    public void update(string[] attributesNames, string[] values, string[] WhereAtributesNames, string[] WhereValues)
    {
        string SQL = getUpdateSQL(dtAttribute, attributesNames, values, WhereAtributesNames, WhereValues);
        Dbase.ChangeTable(SQL, DBName);
    }
    private static string getInsertSQL(DataTable dt, string[] attributesNames, string[] values)
    {
        string SQL = "INSERT INTO " + dt.TableName + " (";
        for (int i = 0; i < attributesNames.Length; i++)
        {
            if (i == attributesNames.Length - 1)
            {
                SQL += "[" + attributesNames[i] + "])";
            }
            else
                SQL += "[" + attributesNames[i] + "],";
        }
        SQL += "VALUES(";
        for (int i = 0; i < values.Length; i++)
        {
            if (i == values.Length - 1)
            {
                if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.DateTime"))
                {
                    SQL += " = #" + DateTime.Parse(values[i]).ToShortDateString() + "#" + ")";
                }
                else if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.String"))
                {
                    SQL += " \'" + values[i] + "\')";
                }
                else
                    SQL += values[i] + ")";
            }
            else
            {
                if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.DateTime"))
                {
                    SQL += " = #" + DateTime.Parse(values[i]).ToShortDateString() + "#" + ",";
                }
                else if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.String"))
                {
                    SQL += " \'" + values[i] + "\',";
                }
                else
                    SQL += values[i] + ",";
            }
        }
        return SQL;
    }
    private static string getDeleteSQL(DataTable dt, string[] attributesNames, string[] values)
    {
        string SQL = "DELETE * FROM " + dt.TableName + " WHERE ";
        for (int i = 0; i < attributesNames.Length; i++)
        {
            if (i == attributesNames.Length - 1)
            {
                if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.DateTime"))
                {
                    SQL += attributesNames[i] + " = #" + DateTime.Parse(values[i]).ToShortDateString() + "#";
                }
                else if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.String"))
                {
                    SQL += attributesNames[i] + "= \'" + values[i] + "\'";
                }
                else
                    SQL += attributesNames[i] + " = " + values[i];

            }
            else
            {
                if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.DateTime"))
                {
                    SQL += attributesNames[i] + " = #" + DateTime.Parse(values[i]).ToShortDateString() + "# AND ";
                }
                else if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.String"))
                {
                    SQL += attributesNames[i] + "= \'" + values[i] + "\' AND ";
                }
                else
                    SQL += attributesNames[i] + " = " + values[i] + " AND ";
            }
        }
        return SQL;
    }
    private static string getUpdateSQL(DataTable dt, string[] attributesNames, string[] values, string[] WhereAtributesNames, string[] WhereValues)
    {
        string SQL = "UPDATE " + dt.TableName + " SET ";
        for (int i = 0; i < attributesNames.Length-1; i++)
        {
            if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.DateTime"))
            {
                SQL += "["+attributesNames[i] + "] = #" + DateTime.Parse(values[i]).ToShortDateString() + "# , ";
            }
            else if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.String"))
            {
                SQL += "["+attributesNames[i] + "] = \'" + values[i] + "\' , ";
            }
            else
                SQL +="[" + attributesNames[i] + "] = " + values[i] + " , ";
        }
        if (dt.Columns[attributesNames[attributesNames.Length - 1]].DataType.ToString().Equals("System.DateTime"))
        {
            SQL += "["+attributesNames[attributesNames.Length - 1] + "] = #" + DateTime.Parse(values[attributesNames.Length - 1]).ToShortDateString() + "# ";
        }
        else if (dt.Columns[attributesNames[attributesNames.Length - 1]].DataType.ToString().Equals("System.String"))
        {
            SQL += "[" + attributesNames[attributesNames.Length - 1] + "]= \'" + values[attributesNames.Length - 1] + "\' ";
        }
        else
            SQL += "[" + attributesNames[attributesNames.Length - 1] + "] = " + values[attributesNames.Length - 1] + " ";
        SQL += " WHERE ";
        for (int i = 0; i < WhereAtributesNames.Length; i++)
        {
            if (i == WhereAtributesNames.Length - 1)
            {
                if (dt.Columns[WhereAtributesNames[i]].DataType.ToString().Equals("System.DateTime"))
                {
                    SQL += WhereAtributesNames[i] + " = #" + DateTime.Parse(WhereValues[i]).ToShortDateString() + "# ";
                }
                else if (dt.Columns[WhereAtributesNames[i]].DataType.ToString().Equals("System.String"))
                {
                    SQL += WhereAtributesNames[i] + "= \'" + WhereValues[i] + "\' ";
                }
                else
                    SQL += WhereAtributesNames[i] + " = " + WhereValues[i] + " ";
            }
            else
            {
                if (dt.Columns[WhereAtributesNames[i]].DataType.ToString().Equals("System.DateTime"))
                {
                    SQL += WhereAtributesNames[i] + " = #" + DateTime.Parse(WhereValues[i]).ToShortDateString() + "# AND ";
                }
                else if (dt.Columns[WhereAtributesNames[i]].DataType.ToString().Equals("System.String"))
                {
                    SQL += WhereAtributesNames[i] + " = \'" + WhereValues[i] + "\' AND ";
                }
                else
                    SQL += WhereAtributesNames[i] + " = " + WhereValues[i] + " AND ";
            }
        }
        return SQL;

    }
    private static string getFindByEqualsSQL(DataTable dt, string[] attributesNames=null, string[] values=null)
    {
        if (attributesNames == null && values != null || attributesNames != null && values == null)
        {
            throw new Exception("Using null pointer");
        }
        if(attributesNames == null)
        {
            return "SELECT * FROM " + dt.TableName;
        }
        string SQL = "SELECT * FROM " + dt.TableName + " WHERE ";
        for (int i = 0; i < attributesNames.Length; i++)
        {
            if (i == attributesNames.Length - 1)
            {
                if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.DateTime"))
                {
                    SQL += attributesNames[i] + " = #" + DateTime.Parse(values[i]).ToShortDateString() + "#";
                }
                else if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.String"))
                {
                    SQL += attributesNames[i] + " = \'" + values[i] + "\'";
                }
                else
                    SQL += attributesNames[i] + " = " + values[i];
            }
            else
            {
                if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.DateTime"))
                {
                    SQL += attributesNames[i] + " = #" + DateTime.Parse(values[i]).ToShortDateString() + "# AND ";
                }
                else if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.String"))
                {
                    SQL += attributesNames[i] + " = \'" + values[i] + "\' AND ";
                }
                else
                    SQL += attributesNames[i] + " = " + values[i] + " AND ";
            }
        }
        return SQL;
    }
    private static string getFindByLikeSQL(DataTable dt, string[] attributesNames, string[] values)
    {
        string SQL = "SELECT * FROM " + dt.TableName + " WHERE ";
        for (int i = 0; i < attributesNames.Length; i++)
        {
            if (attributesNames.Length - 1 == i)
            {
                if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.String"))
                {
                    SQL += attributesNames[i] + "LIKE \'";
                    for (int j = 0; j < values[i].Length; j++)
                    {
                        SQL += "*" + values[i][j] + "*";
                    }
                    SQL += "\' ";
                }
                else
                    return null;
            }
            else
            {
                if (dt.Columns[attributesNames[i]].DataType.ToString().Equals("System.String"))
                {
                    SQL += attributesNames[i] + "LIKE \'";
                    for (int j = 0; j < values[i].Length; j++)
                    {
                        SQL += "*" + values[i][j] + "*";
                    }
                    SQL += "\' AND ";
                }
                else
                    return null;
            }
        }
        return SQL;
    }
    public static void ShowEmptyGridView(GridView gv ,DataTable DataTable1)
    {
        object[] values = new object[DataTable1.Columns.Count];
        for (int i=0;i<DataTable1.Columns.Count;i++)
        {
            if(DataTable1.Columns[i].DataType.ToString().Equals("System.Int32"))
            {
                values[i] = default(System.Int32);
            }
            else if (DataTable1.Columns[i].DataType.ToString().Equals("System.String"))
            {
                values[i] = default(System.String);
            }
            else if (DataTable1.Columns[i].DataType.ToString().Equals("System.DateTime"))
            {
                values[i] = default(System.DateTime);
            }
            else if (DataTable1.Columns[i].DataType.ToString().Equals("System.Boolean"))
            {
                values[i] = default(System.Boolean);
            }
            else
            {
                values[i] = null;
            }
            
        }
        DataTable1.Rows.Add(values);
        gv.DataSource = DataTable1;
        gv.DataBind();
    }
   
}
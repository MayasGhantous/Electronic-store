﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Globalization;
using com.currencysystem.fx;
public partial class ClickedDevice : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                LabelMessage.Text = "";
                if (Request.QueryString["DeviceID"] != null)
                {
                    for (int i = 1; i <= 10; i++)
                    {
                        DropDownListAmount.Items.Add(i.ToString());
                    }
                    ClassDevices CD = new ClassDevices();
                    string[] s1 = { "DeviceID" };
                    string[] s2 = { Request.QueryString["DeviceID"] };
                    CD = (ClassDevices)CD.completeObj(s1, s2);
                    LabelName.Text = CD.getAttributeByString("Name");
                    LabelIMG.Text = string.Format("<img src=\"{0}\" id=featured alt =\"Img not found\"/>", CD.getAttributeByString("OrginalImg"));
                    LabelFirst.Text = string.Format("<img src=\"{0}\" class=\"thumbnail active\" alt =\"Img not found\"/>", CD.getAttributeByString("OrginalImg"));
                    ClassImagesNameGUID cg = new ClassImagesNameGUID();
                    DataTable dt1 = cg.getDataTableWhere(s1, s2);
                    Repeater1.DataSource = dt1;
                    Repeater1.DataBind();
                    RepeaterComments.DataSource = ClassCommentsDevice.GetDataTable(Request.QueryString["DeviceID"]);
                    RepeaterComments.DataBind();
                    //LabelAnotherImges.Text = ClassImagesNameGUID.getAllAdditionalImges(Request.QueryString["DeviceID"]);
                    // LabelIMG.Text = ClassImagesNameGUID.getAllAdditionalImges(Request.QueryString["DeviceID"]);
                    CurrencyServer currency = new CurrencyServer();
                    string name = RegionInfo.CurrentRegion.DisplayName;
                    TextBoxDes.Text = CD.getAttributeByString("Description");
                    if (Session["LoggedInUser"] == null)
                        TextBoxPrice.Text = currency.ConvertToNum("", "USD", currency.CountryToCurrency("", name, true), double.Parse(CD.getAttributeByString("Price")), true, "", "") + " " + currency.CurrencySymbol("", currency.CountryToCurrency("", name, true), "");
                    else
                    {
                        TextBoxPrice.Text = currency.ConvertToNum("", "USD", currency.CountryToCurrency("", ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country"), true), double.Parse(CD.getAttributeByString("Price")), true, "", "") + " " + currency.CurrencySymbol("", currency.CountryToCurrency("", ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("Country"), true), "");

                    }
                    if (Session["LoggedInUser"] == null)
                    {
                        ButtonCart.Text = "Add to the cart";
                        return;
                    }
                    ClassDevicesCarts cdc = ClassDevicesCarts.get(Request.QueryString["DeviceID"], ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"));
                    if (cdc != null)
                    {
                        if (DateTime.Parse(cdc.arrivalTime).ToShortDateString() == "1/1/2001")
                        {

                            ButtonCart.Text = "Book Now";
                        }
                        else
                        {
                            ButtonCart.Text = "Show Arrival Time";
                        }
                    }
                    else
                    {
                        ButtonCart.Text = "Add to the cart";

                    }

                    //   FillTree();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
               
            }
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERORR in ClickedDevice::Page_Load=>" + ex.Message;
        }
    }

    protected void ButtonCart_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["LoggedInUser"] != null)
            {
                if (Request.QueryString["DeviceID"] != null)
                {
                    ClassDevicesCarts obj = new ClassDevicesCarts();

                    if (ButtonCart.Text == "Add to the cart")
                    {
                        ButtonCart.Text = "Book Now";
                        obj = new ClassDevicesCarts(Request.QueryString["DeviceID"], ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"), DropDownListAmount.SelectedValue);
                        obj.Insert();
                    }
                    else if (ButtonCart.Text == "Show Arrival Time")
                    {
                        Response.Redirect("ShowArrivalTime.aspx");

                    }
                    else
                    {
                        obj = ClassDevicesCarts.get(Request.QueryString["DeviceID"], ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"));
                        Session["cartToFlight"] = obj;
                        //ButtonCart.Text = "Add to the cart";
                        //ClassDevicesCarts.Delete(Request.QueryString["DeviceID"], ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"));
                        Response.Redirect("AllFlights.aspx");
                    }
                }
            }
            else
            {
                Response.Redirect("Login.aspx?AddToCarToDeviceID=" + Request.QueryString["DeviceID"]);
            }
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERORR in ClickedDevice::ButtonCart_Click=>" + ex.Message;
        }

    }
    public string DecideIMGDisLike(object o)
    {
        try
        {
            if (Session["LoggedInUser"] != null)
            {
                string[] s1 = { "CommentID", "UserID", "IsLike" };
                string[] s2 = { ((int)o).ToString(), ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"), false.ToString() };
                ClassLikeDislike cld = new ClassLikeDislike();
                cld = (ClassLikeDislike)cld.completeObj(s1, s2);
                if (cld == null)
                {
                    return "img\\Dislike.png";
                }
                else
                {
                    return "img\\FilledDisLike.png";
                }
            }
            else
            {
                return "img\\DisLike.png";
            }
        }
        catch (Exception ex)
        {

            LabelMessage.Text = "ERORR in ClickedDevice::DecideIMGDisLike=>" + ex.Message;
            return "";
        }

    }
    public string DecideIMGLike(object o)
    {
        try
        {

            if (Session["LoggedInUser"] != null)
            {
                string[] s1 = { "CommentID", "UserID", "IsLike" };
                string[] s2 = { ((int)o).ToString(), ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"), true.ToString() };
                ClassLikeDislike cld = new ClassLikeDislike();
                cld = (ClassLikeDislike)cld.completeObj(s1, s2);
                if (cld == null)
                {
                    return "img\\Like.png";
                }
                else
                {
                    return "img\\FilledLike.png";
                }
            }
            else
            {
                return "img\\Like.png";
            }
        }

        catch (Exception ex)
        {

            LabelMessage.Text = "ERORR in ClickedDevice::DecideIMGDisLike=>" + ex.Message;
        }
        return "";
    }

    protected void RepeaterComments_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "insert")
            {
                if (Session["LoggedInUser"] != null)
                {
                    string Content = ((TextBox)RepeaterComments.Controls[0].FindControl("TextBoxHeaderContent")).Text;
                    string Rating = ((TextBox)RepeaterComments.Controls[0].FindControl("TextBoxHeaderRating")).Text;
                    string[] s1 = { "Content", "DeviceID", "CommenterUserID", "CommentRating", "LikeCount", "DislikeCount", "reportsCount", "Date" };
                    string[] s2 = { Content, Request.QueryString["DeviceID"], ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"), Rating, "0", "0", "0", DateTime.Now.ToShortDateString() };
                    ClassCommentsDevice ccd = new ClassCommentsDevice();
                    ccd.insert(s1, s2);
                    RepeaterComments.DataSource = ClassCommentsDevice.GetDataTable(Request.QueryString["DeviceID"]);
                    RepeaterComments.DataBind();
                }
                else
                {
                    Response.Redirect("Login.aspx?AddToCarToDeviceID=" + Request.QueryString["DeviceID"]);
                }
            }
            if (e.CommandName == "like" || e.CommandName == "dislike")
            {
                if (Session["LoggedInUser"] != null)
                {
                    string[] s8 = { "CommentID" };
                    string[] s9 = { (string)e.CommandArgument };
                    ClassCommentsDevice ccd = new ClassCommentsDevice();
                    ccd = (ClassCommentsDevice)ccd.completeObj(s8, s9);
                    string[] s10 = { "LikeCount", "DislikeCount" };
                    string[] s1 = { "CommentID", "UserID" };
                    string[] s2 = { (string)e.CommandArgument, ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID") };
                    ClassLikeDislike cld = new ClassLikeDislike();
                    cld = (ClassLikeDislike)cld.completeObj(s1, s2);
                    string[] s3 = { "CommentID", "UserID", "IsLike" };
                    string[] s4 = { (string)e.CommandArgument, ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"), true.ToString() };
                    string[] s5 = { (string)e.CommandArgument, ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID"), false.ToString() };
                    if (cld == null)
                    {
                        cld = new ClassLikeDislike();
                        if (e.CommandName == "like")
                        {
                            string[] s11 = { (int.Parse(ccd.getAttributeByString("LikeCount")) + 1).ToString(), ccd.getAttributeByString("DislikeCount") };
                            cld.insert(s3, s4);
                            ccd.update(s10, s11, s8, s9);
                        }
                        else
                        {
                            string[] s11 = { ccd.getAttributeByString("LikeCount"), (int.Parse(ccd.getAttributeByString("DislikeCount")) + 1).ToString() };
                            cld.insert(s3, s5);
                            ccd.update(s10, s11, s8, s9);
                        }
                    }
                    else
                    {
                        string[] s6 = { "LikeDislikeID" };
                        string[] s7 = { cld.getAttributeByString("LikeDislikeID") };
                        cld = (ClassLikeDislike)cld.completeObj(s3, s4);
                        if (cld == null)//if it was dislike
                        {
                            cld = new ClassLikeDislike();
                            if (e.CommandName == "like")
                            {

                                string[] s11 = { (int.Parse(ccd.getAttributeByString("LikeCount")) + 1).ToString(), (int.Parse(ccd.getAttributeByString("DislikeCount")) - 1).ToString() };
                                cld.update(s3, s4, s6, s7);
                                ccd.update(s10, s11, s8, s9);
                            }
                            else
                            {
                                string[] s11 = { ccd.getAttributeByString("LikeCount"), (int.Parse(ccd.getAttributeByString("DislikeCount")) - 1).ToString() };
                                cld.delete(s6, s7);
                                ccd.update(s10, s11, s8, s9);
                            }
                        }
                        else
                        {
                            if (e.CommandName == "like")
                            {
                                string[] s11 = { (int.Parse(ccd.getAttributeByString("LikeCount")) - 1).ToString(), ccd.getAttributeByString("DislikeCount") };
                                cld.delete(s6, s7);
                                ccd.update(s10, s11, s8, s9);
                            }
                            else
                            {
                                string[] s11 = { (int.Parse(ccd.getAttributeByString("LikeCount")) - 1).ToString(), (int.Parse(ccd.getAttributeByString("DislikeCount")) + 1).ToString() };
                                cld.update(s3, s5, s6, s7);
                                ccd.update(s10, s11, s8, s9);

                            }
                        }
                    }
                    RepeaterComments.DataSource = ClassCommentsDevice.GetDataTable(Request.QueryString["DeviceID"]);
                    RepeaterComments.DataBind();
                }
                else
                {
                    Response.Redirect("Login.aspx?AddToCarToDeviceID=" + Request.QueryString["DeviceID"]);
                }

            }
            else if (e.CommandName == "Report")
            {
                Response.Redirect("ReportComment.aspx?CommentID=" + e.CommandArgument + "&DeviceID=" + Request.QueryString["DeviceID"]);
            }
            else if (e.CommandName == "Delete")
            {
                string[] s1 = { "CommentID" };
                string[] s2 = { e.CommandArgument.ToString() };
                ClassCommentsDevice ccd = new ClassCommentsDevice();
                ccd.delete(s1, s2);
                RepeaterComments.DataSource = ClassCommentsDevice.GetDataTable(Request.QueryString["DeviceID"]);
                RepeaterComments.DataBind();
            }
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERORR in ClickedDevice::RepeaterComments_ItemCommand=>" + ex.Message;
        }
    }


    public string getReportOrDelete(object obj)
    {
        try
        {
            if (Session["LoggedInUser"] == null)
            {

                return "Report";
            }
            string[] s1 = { "CommentID" };
            string[] s2 = { obj.ToString() };
            ClassCommentsDevice ccd = new ClassCommentsDevice();
            ccd = (ClassCommentsDevice)ccd.completeObj(s1, s2);
            string userID = ((ClassUsers)Session["LoggedInUser"]).getAttributeByString("UserID");
            if (ccd.getAttributeByString("CommenterUserID") == userID)
            {

                return "Delete";
            }
            else
            {

                return "Report";
            }
        }
        catch (Exception ex)
        {
            LabelMessage.Text = "ERORR in ClickedDevice::getReportOrDelete=>" + ex.Message;

        }
        return "";
    }


}
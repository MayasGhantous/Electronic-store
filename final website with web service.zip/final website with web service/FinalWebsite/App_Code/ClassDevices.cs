﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ClassDevices
/// </summary>
public class ClassDevices : GeneralASPClass
{
    //we need getAvailabelDevices,getDeviceAbove
    private static DataTable dt = Dbase.SelectFromTable("SELECT * FROM DevicesTable","DB.accdb");
    
    public ClassDevices():base("DevicesTable", "DB.accdb")
    {
        //
        // TODO: Add constructor logic here
        //
    }
    //protected override void NameDataTable()
    //{
    //    dtAttribute.TableName = "DevicesTable";
    //}
    public static DataTable getAvailabelDevices(string Type,string Price="",string Rating="")
    {
        if (Price!=""&&Rating!="")
        {
            string sql = "SELECT * FROM DevicesTable WHERE Type=\"" + Type + "\" AND Price <= " + Price + " AND Rate >=" + Rating + " ORDER BY Rate DESC, Price ASC";
            return Dbase.SelectFromTable(sql, "DB.accdb");
        }
        else if(Price != "")
        {
            string sql = "SELECT * FROM DevicesTable WHERE Type=\"" + Type + "\" AND Price <= " + Price + " ORDER BY Rate DESC, Price ASC";
            return Dbase.SelectFromTable(sql, "DB.accdb");
        }
        else if(Rating!="")
        {
            string sql = "SELECT * FROM DevicesTable WHERE Type=\"" + Type + "\" AND Rate >=" + Rating + " ORDER BY Rate DESC, Price ASC";
            return Dbase.SelectFromTable(sql, "DB.accdb");
        }
        else
        {
            string sql = "SELECT * FROM DevicesTable WHERE Type=\"" + Type + "\" ORDER BY Rate DESC, Price ASC";
            return Dbase.SelectFromTable(sql, "DB.accdb");
        }
    }
    public static DataTable getDeviceAbove(string Rating)
    {
        
            string sql = "SELECT * FROM DevicesTable WHERE Rate >=" + Rating + " ORDER BY Rate DESC, Price ASC";
            return Dbase.SelectFromTable(sql, "DB.accdb");
        
    }


}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

public partial class RestorePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void ButtonGetCode_Click(object sender, EventArgs e)
    {
        ClassUsers obj = new ClassUsers();
        try
        {
            
        string[] s1 = {"Email","UserName" };
        string[] s2 = { TextBoxEmail.Text, TextBoxUserName.Text };
        obj= (ClassUsers)obj.completeObj(s1,s2);
        if (obj == null )
        {
            LabelMessage.Text ="Your UserName or Email are not correct";
            return;
        }
        else if(bool.Parse(obj.getAttributeByString("Isbanned")))
        {
            LabelMessage.Text = "You have been banned for not following the website rules you can contact us if you think that we made a misatake\n you will be unbanned at " + obj.getAttributeByString("Last_day") ;
            return;
        }
        else
        {
            LabelMessage.Text = "";
        }
        
            MailMessage message = new MailMessage();
            SmtpClient smtp = new SmtpClient();
            message.From = new MailAddress("new.eshop123@gmail.com");
            message.To.Add(new MailAddress(TextBoxEmail.Text));
            message.Subject = "Code";
            Random R = new Random();
            int num = R.Next(100000, 999999);
            Session["Code"] = num.ToString();
            message.Body = string.Format("Hello\nYour code is {0}",num);
            smtp.Port = 587;
            smtp.Host = "smtp.gmail.com"; //for gmail host  
            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential("new.eshop123@gmail.com", "Mma213461692");
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Send(message);
            Session["To_Password"] = true;
            Session["HowForgotPassword"] = obj;
            Response.Redirect("Verify.aspx");

        }
        catch (Exception ex) { LabelMessage.Text = "ERROR in RestorePassword::ButtonGetCode_Click=>"+ex.Message; return; }
        
    }
}